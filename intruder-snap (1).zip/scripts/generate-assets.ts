import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import { ANDROID_FILES } from '../src/services/androidProject.ts';

async function buildPublicAssets() {
  const publicDir = path.resolve('public');
  if (!fs.existsSync(publicDir)) {
    fs.mkdirSync(publicDir, { recursive: true });
  }

  // 1. Generate ZIP of Android Studio Project
  const zip = new JSZip();
  for (const file of ANDROID_FILES) {
    zip.file(`LockGuard-Android13/${file.path}`, file.content);
  }

  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });

  const zipPath = path.join(publicDir, 'LockGuard-Android13-Complete-Project.zip');
  fs.writeFileSync(zipPath, zipBuffer);
  const zipSizeKb = (zipBuffer.length / 1024).toFixed(1);
  console.log(`ZIP created successfully at ${zipPath} (${zipSizeKb} KB)`);

  // 2. Generate Offline HTML file
  const offlineHtmlContent = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>حارس قفل الشاشة الذكي | Lock Guard</title>
  <meta name="theme-color" content="#020617">
  <meta name="mobile-web-app-capable" content="yes">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Tajawal', system-ui, sans-serif; }
    .mono { font-family: 'JetBrains Mono', monospace; }
  </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen flex flex-col antialiased">
  <header class="bg-slate-900 border-b border-slate-800 p-3 flex items-center justify-between sticky top-0 z-30">
    <div class="flex items-center gap-2">
      <div class="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold">🛡️</div>
      <span class="font-bold text-sm">حارس قفل الشاشة (Offline)</span>
    </div>
    <div class="flex items-center gap-2">
      <button onclick="toggleLock(true)" class="px-3 py-1.5 bg-teal-500 text-slate-950 font-bold text-xs rounded-xl shadow">🔒 قفل الشاشة الآن</button>
    </div>
  </header>

  <div id="lockScreen" class="fixed inset-0 bg-slate-950 z-50 flex flex-col justify-between p-6 hidden select-none">
    <div class="flex flex-col items-center pt-8">
      <div class="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-teal-400 text-xl mb-4">🔒</div>
      <div id="clockDisplay" class="text-6xl font-light mono text-white mb-1">12:00</div>
      <div class="text-xs text-slate-400 mb-4">جهازك في أمان تام</div>
      <div class="bg-teal-950/60 border border-teal-800/60 text-teal-400 text-xs px-3 py-1 rounded-full">الحارس يراقب بالكاميرا الأمامية</div>
      <p class="text-xs text-slate-400 mt-3">الرمز الصحيح: <strong class="text-teal-400 mono">1234</strong> (أدخل رمزاً خاطئاً لاختبار الالتقاط)</p>
    </div>

    <div class="w-full max-w-xs mx-auto">
      <div id="pinDots" class="flex justify-center gap-3 mb-6">
        <span class="w-3.5 h-3.5 rounded-full border border-slate-600"></span>
        <span class="w-3.5 h-3.5 rounded-full border border-slate-600"></span>
        <span class="w-3.5 h-3.5 rounded-full border border-slate-600"></span>
        <span class="w-3.5 h-3.5 rounded-full border border-slate-600"></span>
      </div>
      <div id="lockFeedback" class="text-center text-xs text-rose-400 font-bold mb-3 h-4"></div>
      <div class="grid grid-cols-3 gap-3 mono" dir="ltr">
        <button onclick="pressDigit('1')" class="h-14 rounded-full bg-slate-900 border border-slate-800 text-lg font-bold">1</button>
        <button onclick="pressDigit('2')" class="h-14 rounded-full bg-slate-900 border border-slate-800 text-lg font-bold">2</button>
        <button onclick="pressDigit('3')" class="h-14 rounded-full bg-slate-900 border border-slate-800 text-lg font-bold">3</button>
        <button onclick="pressDigit('4')" class="h-14 rounded-full bg-slate-900 border border-slate-800 text-lg font-bold">4</button>
        <button onclick="pressDigit('5')" class="h-14 rounded-full bg-slate-900 border border-slate-800 text-lg font-bold">5</button>
        <button onclick="pressDigit('6')" class="h-14 rounded-full bg-slate-900 border border-slate-800 text-lg font-bold">6</button>
        <button onclick="pressDigit('7')" class="h-14 rounded-full bg-slate-900 border border-slate-800 text-lg font-bold">7</button>
        <button onclick="pressDigit('8')" class="h-14 rounded-full bg-slate-900 border border-slate-800 text-lg font-bold">8</button>
        <button onclick="pressDigit('9')" class="h-14 rounded-full bg-slate-900 border border-slate-800 text-lg font-bold">9</button>
        <button onclick="clearPin()" class="h-14 rounded-full text-slate-400 text-xs font-sans">مسح</button>
        <button onclick="pressDigit('0')" class="h-14 rounded-full bg-slate-900 border border-slate-800 text-lg font-bold">0</button>
        <button onclick="deleteDigit()" class="h-14 rounded-full text-slate-400 text-sm">⌫</button>
      </div>
      <div class="text-center mt-4">
        <button onclick="toggleLock(false)" class="text-xs text-slate-400 hover:text-teal-400">تجاوز القفل (المالك)</button>
      </div>
    </div>
  </div>

  <div id="whiteFlash" class="fixed inset-0 bg-white z-50 pointer-events-none opacity-0 transition-opacity duration-200"></div>

  <main class="flex-1 max-w-4xl mx-auto w-full p-4 flex flex-col gap-4">
    <div class="bg-slate-900 border border-slate-800 p-4 rounded-2xl flex items-center justify-between">
      <div>
        <h2 class="text-sm font-bold text-slate-100">معرض لقطات المتطفلين</h2>
        <p class="text-xs text-slate-400">توثيق صور أي شخص يكتب رمز القفل بشكل خاطئ</p>
      </div>
      <div class="flex items-center gap-2">
        <button onclick="clearAllLogs()" class="px-3 py-1.5 text-xs text-rose-400 border border-rose-900/60 rounded-xl hover:bg-rose-950/40">مسح الكل</button>
      </div>
    </div>

    <div id="galleryContainer" class="grid grid-cols-2 sm:grid-cols-3 gap-3"></div>
  </main>

  <script>
    let currentPin = '';
    const correctPin = '1234';
    let logs = JSON.parse(localStorage.getItem('lockguard_offline_logs') || '[]');

    function updateClock() {
      const d = new Date();
      const el = document.getElementById('clockDisplay');
      if (el) el.innerText = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    }
    setInterval(updateClock, 1000);
    updateClock();

    function toggleLock(locked) {
      document.getElementById('lockScreen').classList.toggle('hidden', !locked);
      currentPin = '';
      updateDots();
      document.getElementById('lockFeedback').innerText = '';
    }

    function pressDigit(d) {
      if (currentPin.length < 4) {
        currentPin += d;
        updateDots();
        if (currentPin.length === 4) verifyPin();
      }
    }

    function deleteDigit() {
      currentPin = currentPin.slice(0, -1);
      updateDots();
    }

    function clearPin() {
      currentPin = '';
      updateDots();
    }

    function updateDots() {
      const dots = document.querySelectorAll('#pinDots span');
      dots.forEach((dot, idx) => {
        if (idx < currentPin.length) {
          dot.className = 'w-3.5 h-3.5 rounded-full bg-teal-400 shadow';
        } else {
          dot.className = 'w-3.5 h-3.5 rounded-full border border-slate-600';
        }
      });
    }

    async function verifyPin() {
      if (currentPin === correctPin) {
        toggleLock(false);
      } else {
        const attempted = currentPin;
        document.getElementById('lockFeedback').innerText = 'رمز خاطئ! جاري التقاط الصورة بالكاميرا...';
        flashScreen();
        const photo = await captureCameraSnapshot();
        const newLog = {
          id: 'log_' + Date.now(),
          time: new Date().toLocaleString('ar-EG'),
          code: attempted,
          image: photo
        };
        logs.unshift(newLog);
        localStorage.setItem('lockguard_offline_logs', JSON.stringify(logs));
        renderGallery();
        setTimeout(() => {
          currentPin = '';
          updateDots();
          document.getElementById('lockFeedback').innerText = 'تم التقاط الصورة وتوثيق المحاولة!';
        }, 500);
      }
    }

    function flashScreen() {
      const f = document.getElementById('whiteFlash');
      f.style.opacity = '1';
      setTimeout(() => f.style.opacity = '0', 250);
    }

    async function captureCameraSnapshot() {
      try {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
          const video = document.createElement('video');
          video.srcObject = stream;
          video.muted = true;
          await video.play();
          await new Promise(r => setTimeout(r, 200));
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth || 640;
          canvas.height = video.videoHeight || 480;
          const ctx = canvas.getContext('2d');
          ctx.translate(canvas.width, 0);
          ctx.scale(-1, 1);
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          stream.getTracks().forEach(t => t.stop());
          return canvas.toDataURL('image/jpeg', 0.85);
        }
      } catch (e) {
        console.warn('Camera failed or denied, using simulation:', e);
      }
      return generateSimulationPhoto();
    }

    function generateSimulationPhoto() {
      const c = document.createElement('canvas');
      c.width = 480; c.height = 640;
      const ctx = c.getContext('2d');
      ctx.fillStyle = '#0f172a'; ctx.fillRect(0,0,480,640);
      ctx.fillStyle = '#334155'; ctx.beginPath(); ctx.arc(240, 240, 90, 0, Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(240, 480, 180, 140, 0, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = '#ef4444'; ctx.font = 'bold 20px monospace'; ctx.textAlign = 'center';
      ctx.fillText('محاولة فتح غير مصرح بها', 240, 600);
      return c.toDataURL('image/jpeg');
    }

    function renderGallery() {
      const c = document.getElementById('galleryContainer');
      if (logs.length === 0) {
        c.innerHTML = '<div class="col-span-full py-12 text-center text-slate-500 text-xs">لا توجد صور ملتقطة بعد. اضغط "قفل الشاشة الآن" وجرب إدخال رمز خاطئ.</div>';
        return;
      }
      c.innerHTML = logs.map(l => \`
        <div class="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow">
          <img src="\${l.image}" class="w-full aspect-3/4 object-cover">
          <div class="p-2 text-right">
            <div class="text-[11px] font-bold text-white">\${l.time}</div>
            <div class="text-[10px] text-rose-400 font-mono">رمز خاطئ: [\${l.code}]</div>
          </div>
        </div>
      \`).join('');
    }

    function clearAllLogs() {
      if (confirm('هل تريد مسح جميع اللقطات؟')) {
        logs = [];
        localStorage.removeItem('lockguard_offline_logs');
        renderGallery();
      }
    }

    renderGallery();
  </script>
</body>
</html>`;

  const htmlPath = path.join(publicDir, 'LockGuard-Android-App.html');
  fs.writeFileSync(htmlPath, offlineHtmlContent, 'utf-8');
  const htmlSizeKb = (Buffer.byteLength(offlineHtmlContent) / 1024).toFixed(1);
  console.log(`HTML created successfully at ${htmlPath} (${htmlSizeKb} KB)`);
}

buildPublicAssets().catch(console.error);
