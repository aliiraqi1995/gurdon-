/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import {
  Lock,
  Unlock,
  ShieldCheck,
  ShieldAlert,
  Camera,
  Image,
  Sliders,
  Info,
  FolderCode,
  BatteryCharging,
  Bell,
  RefreshCw,
  ExternalLink,
  Smartphone,
  Download,
  Package,
  ArrowRight,
} from 'lucide-react';
import { IntruderLog, AppSettings, PermissionStatus } from './types';
import {
  loadSettings,
  saveSettings,
  loadPermissions,
  savePermissions,
  loadIntruderLogs,
  addIntruderLog,
  deleteIntruderLog,
  clearAllIntruderLogs,
} from './services/storage';
import { downloadAndroidProjectZip } from './services/androidProject';
import AndroidStatusBar from './components/AndroidStatusBar';
import LockScreen from './components/LockScreen';
import GalleryView from './components/GalleryView';
import PermissionsManager from './components/PermissionsManager';
import AndroidSourceModal from './components/AndroidSourceModal';
import SettingsModal from './components/SettingsModal';
import AboutModal from './components/AboutModal';
import InstallModal from './components/InstallModal';
import BuildAPKModal from './components/BuildAPKModal';

// High-fidelity generated app icon
const APP_ICON_URL = '/src/assets/images/lock_guard_icon_1793136119675.jpg';

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [permissions, setPermissions] = useState<PermissionStatus>(() => loadPermissions());
  const [logs, setLogs] = useState<IntruderLog[]>(() => loadIntruderLogs());

  // Navigation state
  const [activeTab, setActiveTab] = useState<'gallery' | 'permissions' | 'code'>('gallery');
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [showAboutModal, setShowAboutModal] = useState<boolean>(false);
  const [showSourceModal, setShowSourceModal] = useState<boolean>(false);
  const [showInstallModal, setShowInstallModal] = useState<boolean>(false);
  const [showBuildModal, setShowBuildModal] = useState<boolean>(false);

  // New intruder alert toast
  const [newCaptureAlert, setNewCaptureAlert] = useState<string | null>(null);

  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  useEffect(() => {
    savePermissions(permissions);
  }, [permissions]);

  const handleNewIntruder = (newLog: IntruderLog) => {
    const updated = addIntruderLog(newLog);
    setLogs(updated);
    setNewCaptureAlert(`🚨 تم رصد متطفل والتقاط صورته بالكاميرا الأمامية! (رمز: ${newLog.attemptedCode})`);
  };

  const handleDeleteLog = (id: string) => {
    const updated = deleteIntruderLog(id);
    setLogs(updated);
  };

  const handleClearAllLogs = () => {
    clearAllIntruderLogs();
    setLogs([]);
  };

  const handleUnlock = (newIntruderCaptured: boolean) => {
    setIsLocked(false);
    if (newIntruderCaptured) {
      setActiveTab('gallery');
    }
  };

  const handleToggleGuard = () => {
    setSettings((prev) => ({
      ...prev,
      isGuardActive: !prev.isGuardActive,
    }));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-teal-500 selection:text-black">
      {/* FULL SCREEN LOCK OVERLAY (WHEN PHONE IS LOCKED) */}
      {isLocked && (
        <div className="fixed inset-0 z-50 bg-slate-950 flex items-center justify-center animate-fadeIn">
          <div className="w-full max-w-md h-full sm:h-[90vh] sm:max-h-[840px] sm:rounded-3xl overflow-hidden border border-slate-800 shadow-2xl relative">
            <LockScreen
              settings={settings}
              onUnlock={handleUnlock}
              onNewIntruder={handleNewIntruder}
            />
          </div>
        </div>
      )}

      {/* TOP BAR CONTRACT: Zone 1 (Wordmark) - Zone 2 (4-5 Nav Links) - Zone 3 (1 Primary CTA) */}
      <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-800 px-4 sm:px-8 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
          {/* Zone 1: Wordmark */}
          <div className="flex items-center gap-2.5 shrink-0">
            <img
              src={APP_ICON_URL}
              alt="أيقونة حارس القفل"
              className="w-8 h-8 rounded-xl object-cover shadow-sm border border-teal-500/30"
            />
            <span className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0">
              حارس قفل الشاشة
            </span>
          </div>

          {/* Zone 2: Concise Nav Links */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-300">
            <button
              type="button"
              onClick={() => setActiveTab('gallery')}
              className={`hover:text-teal-400 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'gallery' ? 'text-teal-400 font-bold underline underline-offset-8' : ''
              }`}
            >
              معرض اللقطات ({logs.length})
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('permissions')}
              className={`hover:text-teal-400 transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'permissions' ? 'text-teal-400 font-bold underline underline-offset-8' : ''
              }`}
            >
              الصلاحيات والبطارية
            </button>
            <button
              type="button"
              onClick={() => setShowBuildModal(true)}
              className="text-amber-300 font-bold hover:text-amber-200 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
            >
              <Package className="w-3.5 h-3.5" />
              <span>بناء التطبيق كاملاً (APK)</span>
            </button>
            <button
              type="button"
              onClick={() => setShowInstallModal(true)}
              className="hover:text-teal-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل (رابط / QR)</span>
            </button>
            <button
              type="button"
              onClick={() => setShowSourceModal(true)}
              className="hover:text-teal-400 transition-colors whitespace-nowrap shrink-0"
            >
              مشروع أندرويد (Kotlin)
            </button>
            <button
              type="button"
              onClick={() => setShowSettingsModal(true)}
              className="hover:text-teal-400 transition-colors whitespace-nowrap shrink-0"
            >
              الإعدادات
            </button>
            <button
              type="button"
              onClick={() => setShowAboutModal(true)}
              className="hover:text-teal-400 transition-colors whitespace-nowrap shrink-0"
            >
              حول التطبيق
            </button>
          </nav>

          {/* Zone 3: 1 Primary Action */}
          <div className="flex items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => setShowBuildModal(true)}
              className="hidden sm:flex px-3.5 py-2 text-xs font-bold text-amber-300 bg-amber-950/80 hover:bg-amber-900/80 border border-amber-600/60 rounded-xl transition-all items-center gap-1.5 whitespace-nowrap shrink-0"
              title="كيف تبني ملف APK جاهز للتثبيت"
            >
              <Package className="w-3.5 h-3.5 text-amber-400" />
              <span>بناء ملف التطبيق (APK)</span>
            </button>
            <button
              type="button"
              onClick={() => setIsLocked(true)}
              className="px-4 py-2 text-xs font-bold text-slate-950 bg-teal-400 hover:bg-teal-300 rounded-xl transition-all shadow-md shadow-teal-500/20 active:scale-95 flex items-center gap-1.5 whitespace-nowrap shrink-0"
              title="تجربة قفل الشاشة ومحاكاة كتابة رمز خاطئ"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>قفل الشاشة الآن</span>
            </button>
          </div>
        </div>
      </header>

      {/* Real-time Android Status Bar Simulation on mobile/tablet */}
      <div className="max-w-7xl mx-auto w-full px-4 pt-3 pb-1">
        <div className="bg-slate-900/90 rounded-2xl border border-slate-800/80 overflow-hidden shadow-sm">
          <AndroidStatusBar isGuardActive={settings.isGuardActive} />
        </div>
      </div>

      {/* Intruder Alert Toast Banner */}
      {newCaptureAlert && (
        <div className="max-w-7xl mx-auto w-full px-4 my-2">
          <div className="bg-rose-950/80 border border-rose-700/60 p-3.5 rounded-2xl flex items-center justify-between gap-3 text-rose-200 text-xs shadow-lg animate-bounce">
            <div className="flex items-center gap-2.5">
              <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0" />
              <span className="font-semibold">{newCaptureAlert}</span>
            </div>
            <button
              type="button"
              onClick={() => {
                setNewCaptureAlert(null);
                setActiveTab('gallery');
              }}
              className="px-3 py-1 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-colors whitespace-nowrap"
            >
              عرض الصور الآن
            </button>
          </div>
        </div>
      )}

      {/* MAIN VIEWPORT CONTENT */}
      <main className="max-w-7xl mx-auto w-full px-4 py-4 flex-1 flex flex-col gap-5">
        {/* Android 13 Overview Card & Guard Status */}
        <section className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-800/60 border border-slate-800 rounded-3xl p-5 shadow-sm">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div className="flex items-start gap-4">
              <img
                src={APP_ICON_URL}
                alt="حارس قفل الشاشة"
                className="w-16 h-16 rounded-2xl object-cover border border-teal-500/30 shadow-md shrink-0"
              />
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <h1 className="text-lg sm:text-xl font-bold text-slate-100">
                    حارس قفل الشاشة التلقائي (Android 13 Guard)
                  </h1>
                  {settings.isGuardActive ? (
                    <span className="text-teal-400 text-xs font-semibold bg-teal-950/60 border border-teal-800/60 px-2 py-0.5 rounded-lg flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> قيد المراقبة
                    </span>
                  ) : (
                    <span className="text-slate-400 text-xs font-semibold bg-slate-800 px-2 py-0.5 rounded-lg">
                      متوقف
                    </span>
                  )}
                </div>

                {/* Clean unboxed metadata with dot separators */}
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                  <span>أندرويد 13 (Tiramisu)</span>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span>الكاميرا الأمامية خفية</span>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span>الرمز الحالي: <strong className="font-mono text-teal-300">{settings.correctPin}</strong></span>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span>الحساسية: {settings.maxFailedAttempts === 1 ? 'من أول خطأ' : `${settings.maxFailedAttempts} أخطاء`}</span>
                </div>
              </div>
            </div>

            {/* Quick Actions Row */}
            <div className="flex flex-wrap items-center gap-2.5 pt-2 lg:pt-0">
              <button
                type="button"
                onClick={handleToggleGuard}
                className={`py-2 px-3.5 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 ${
                  settings.isGuardActive
                    ? 'bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-500/30'
                    : 'bg-teal-500 hover:bg-teal-400 text-slate-950'
                }`}
              >
                {settings.isGuardActive ? <ShieldCheck className="w-4 h-4" /> : <ShieldAlert className="w-4 h-4" />}
                <span>{settings.isGuardActive ? 'الحارس مفعل' : 'تفعيل الحارس'}</span>
              </button>

              <button
                type="button"
                onClick={() => setIsLocked(true)}
                className="py-2 px-3.5 text-xs font-bold rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 transition-colors flex items-center gap-1.5"
              >
                <Smartphone className="w-4 h-4" />
                <span>تجربة إدخال رمز خطأ</span>
              </button>

              <button
                type="button"
                onClick={() => setShowInstallModal(true)}
                className="py-2 px-3.5 text-xs font-bold rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Download className="w-4 h-4" />
                <span>تحميل على هاتفك</span>
              </button>

              <button
                type="button"
                onClick={() => setShowSourceModal(true)}
                className="py-2 px-3.5 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors flex items-center gap-1.5"
              >
                <FolderCode className="w-4 h-4 text-teal-400" />
                <span>ملفات أندرويد (ZIP)</span>
              </button>

              <button
                type="button"
                onClick={() => setShowSettingsModal(true)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                title="إعدادات الحارس"
              >
                <Sliders className="w-4 h-4" />
              </button>
            </div>
          </div>
        </section>

        {/* Highlighted Banner for Build APK & Complete File */}
        <div className="bg-gradient-to-r from-teal-950/70 via-slate-900 to-indigo-950/70 border border-teal-500/40 rounded-3xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-teal-500/20 text-teal-300 flex items-center justify-center shrink-0 border border-teal-500/30">
              <Package className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 mb-0.5">
                <span className="text-[11px] font-bold text-amber-300 bg-amber-950/80 border border-amber-800/60 px-2 py-0.5 rounded-md">
                  طلبك جاهز
                </span>
                <h3 className="text-sm sm:text-base font-bold text-white">
                  تريد بناء التطبيق أو الحصول على ملف التطبيق كاملاً وجاهزاً؟
                </h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                وفرنا لك: ملفاً مستقلاً جاهزاً فوراً للتشغيل على هاتفك (بدون بناء نهائياً)، أو بناء ملف APK أصلي في 3 دقائق بـ Android Studio، أو بناءه سحابياً.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowBuildModal(true)}
              className="w-full sm:w-auto py-2.5 px-4 rounded-xl bg-teal-400 hover:bg-teal-300 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-teal-500/20 transition-all active:scale-95"
            >
              <span>فتح خيارات بناء وتنزيل التطبيق</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Selection Filter Bar (Functional buttons) */}
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 rounded-2xl border border-slate-800 self-start">
          <button
            type="button"
            onClick={() => setActiveTab('gallery')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-1.5 ${
              activeTab === 'gallery'
                ? 'bg-teal-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>معرض لقطات المتطفلين ({logs.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('permissions')}
            className={`px-4 py-2 text-xs font-semibold rounded-xl transition-all flex items-center gap-1.5 ${
              activeTab === 'permissions'
                ? 'bg-teal-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>صلاحيات أندرويد 13 والبطارية</span>
          </button>
        </div>

        {/* TAB 1: GALLERY */}
        {activeTab === 'gallery' && (
          <section className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold text-slate-200">سجل الصور الملتقطة تلقائياً</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  توثيق كامل لكل من حاول فتح القفل مع التاريخ، الوقت، والرمز الخاطئ الذي تم إدخاله
                </p>
              </div>
            </div>

            <GalleryView
              logs={logs}
              viewMode={settings.viewMode}
              onToggleViewMode={(mode) => setSettings({ ...settings, viewMode: mode })}
              onDeleteLog={handleDeleteLog}
              onClearAll={handleClearAllLogs}
            />
          </section>
        )}

        {/* TAB 2: PERMISSIONS & BATTERY */}
        {activeTab === 'permissions' && (
          <section className="flex flex-col gap-3">
            <PermissionsManager
              permissions={permissions}
              onUpdatePermissions={setPermissions}
            />
          </section>
        )}
      </main>

      {/* MOBILE BOTTOM NAVIGATION ANCHOR (Hidden on Desktop) */}
      <div className="md:hidden sticky bottom-0 z-40 bg-slate-950/90 backdrop-blur-md border-t border-slate-800 px-3 py-2">
        <div className="grid grid-cols-5 items-center">
          <button
            type="button"
            onClick={() => setActiveTab('gallery')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'gallery' ? 'text-teal-400' : 'text-slate-400'
            }`}
          >
            <Camera className="w-5 h-5" />
            <span className="text-[10px] font-medium mt-1">اللقطات</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('permissions')}
            className={`flex flex-col items-center justify-center py-1 transition-colors ${
              activeTab === 'permissions' ? 'text-teal-400' : 'text-slate-400'
            }`}
          >
            <ShieldCheck className="w-5 h-5" />
            <span className="text-[10px] font-medium mt-1">الأذونات</span>
          </button>

          <button
            type="button"
            onClick={() => setIsLocked(true)}
            className="flex flex-col items-center justify-center py-1 text-teal-400"
          >
            <div className="w-8 h-8 rounded-full bg-teal-500 text-slate-950 flex items-center justify-center -mt-2 shadow-md shadow-teal-500/30">
              <Lock className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-bold mt-1">القفل</span>
          </button>

          <button
            type="button"
            onClick={() => setShowInstallModal(true)}
            className="flex flex-col items-center justify-center py-1 text-teal-300 hover:text-teal-200"
          >
            <Download className="w-5 h-5" />
            <span className="text-[10px] font-medium mt-1">تحميل</span>
          </button>

          <button
            type="button"
            onClick={() => setShowSettingsModal(true)}
            className="flex flex-col items-center justify-center py-1 text-slate-400 hover:text-slate-200"
          >
            <Sliders className="w-5 h-5" />
            <span className="text-[10px] font-medium mt-1">الإعدادات</span>
          </button>
        </div>
      </div>

      {/* FOOTER */}
      <footer className="border-t border-slate-800/60 py-6 px-4 text-center text-xs text-slate-500 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span>حارس قفل الشاشة الذكي · أندرويد 13/14</span>
            <span aria-hidden="true">·</span>
            <span>حماية محلية 100% بدون خوادم</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <button
              type="button"
              onClick={() => setShowInstallModal(true)}
              className="text-teal-400 font-bold hover:underline transition-colors flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل التطبيق على هاتفك</span>
            </button>
            <button
              type="button"
              onClick={() => setShowAboutModal(true)}
              className="hover:text-teal-400 transition-colors"
            >
              حول النظام
            </button>
            <button
              type="button"
              onClick={() => setShowSourceModal(true)}
              className="hover:text-teal-400 transition-colors"
            >
              تحميل مشروع أندرويد
            </button>
          </div>
        </div>
      </footer>

      {/* MODALS */}
      {showSettingsModal && (
        <SettingsModal
          settings={settings}
          appIconUrl={APP_ICON_URL}
          onSave={setSettings}
          onClose={() => setShowSettingsModal(false)}
        />
      )}

      {showAboutModal && (
        <AboutModal
          appIconUrl={APP_ICON_URL}
          onClose={() => setShowAboutModal(false)}
        />
      )}

      {showSourceModal && (
        <AndroidSourceModal
          onClose={() => setShowSourceModal(false)}
        />
      )}

      {showInstallModal && (
        <InstallModal
          appIconUrl={APP_ICON_URL}
          onClose={() => setShowInstallModal(false)}
          onOpenAndroidSource={() => setShowSourceModal(true)}
        />
      )}

      {showBuildModal && (
        <BuildAPKModal
          appIconUrl={APP_ICON_URL}
          onClose={() => setShowBuildModal(false)}
          onOpenAndroidSource={() => setShowSourceModal(true)}
        />
      )}
    </div>
  );
}
