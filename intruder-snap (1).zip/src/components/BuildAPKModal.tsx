import { useState } from 'react';
import {
  X,
  Package,
  Download,
  FolderArchive,
  Terminal,
  Cpu,
  Smartphone,
  CheckCircle2,
  ExternalLink,
  Github,
  Play,
  ArrowRight,
  FileCheck,
} from 'lucide-react';
import { downloadAndroidProjectZip, downloadOfflineHtmlApp } from '../services/androidProject';

interface BuildAPKModalProps {
  appIconUrl: string;
  onClose: () => void;
  onOpenAndroidSource: () => void;
}

export default function BuildAPKModal({
  appIconUrl,
  onClose,
  onOpenAndroidSource,
}: BuildAPKModalProps) {
  const [activeTab, setActiveTab] = useState<'instant' | 'androidStudio' | 'github'>('instant');
  const [isZipping, setIsZipping] = useState<boolean>(false);

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md">
      <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/30 shadow-md">
              <Package className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-100">
                كيف تبني وتحصل على ملف التطبيق كاملاً وجاهزاً؟
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                اختر الطريقة التي تفضلها للحصول على ملف التطبيق وتشغيله فوراً
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection Filter */}
        <div className="grid grid-cols-3 gap-2 mt-4 p-1 bg-slate-950 rounded-2xl border border-slate-800">
          <button
            type="button"
            onClick={() => setActiveTab('instant')}
            className={`py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'instant'
                ? 'bg-teal-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCheck className="w-4 h-4" />
            <span className="truncate">1. ملف جاهز فوراً (بدون بناء)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('androidStudio')}
            className={`py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'androidStudio'
                ? 'bg-teal-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-4 h-4" />
            <span className="truncate">2. بناء APK بـ Android Studio</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('github')}
            className={`py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'github'
                ? 'bg-teal-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Github className="w-4 h-4" />
            <span className="truncate">3. بناء سحابي أوتوماتيكي</span>
          </button>
        </div>

        {/* TAB 1: INSTANT READY FILE (NO BUILD REQUIRED) */}
        {activeTab === 'instant' && (
          <div className="flex flex-col gap-4 mt-4 animate-fadeIn">
            <div className="bg-gradient-to-r from-teal-950/60 to-slate-950 border border-teal-500/40 rounded-3xl p-5 shadow-sm">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xs font-bold text-teal-300 bg-teal-900/60 border border-teal-700/60 px-2.5 py-0.5 rounded-lg">
                  جاهز للتشغيل مباشرة 100%
                </span>
              </div>
              <h4 className="text-base font-bold text-slate-100 mb-2">
                تحميل ملف التطبيق الكامل الجاهز (LockGuard-Android-App.html)
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-4">
                لقد قمنا بتجميع وبرمجة كافة وظائف التطبيق (الكاميرا الأمامية الخفية، قفل الشاشة برمز PIN، التقاط الصور عند الخطأ، ومعرض اللقطات المؤرخة) داخل <strong>ملف تطبيقي واحد مستقل بالكامل</strong>.
                لا تحتاج لتثبيت أي برامج أو تجميع أكواد!
              </p>

              <button
                type="button"
                onClick={downloadOfflineHtmlApp}
                className="w-full sm:w-auto py-3 px-6 rounded-2xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-teal-500/20 transition-all active:scale-95"
              >
                <Download className="w-4 h-4" />
                <span>تحميل ملف التطبيق الجاهز الآن (تنزيل فوري)</span>
              </button>
            </div>

            {/* How to use */}
            <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5 text-xs text-slate-300">
              <h5 className="font-bold text-slate-100 mb-3 flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-teal-400" />
                <span>كيف تشغله وتثبته على هاتفك الأندرويد في 10 ثوانٍ؟</span>
              </h5>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800">
                  <div className="w-6 h-6 rounded-full bg-teal-500 text-slate-950 font-bold flex items-center justify-center mb-2 text-xs">
                    1
                  </div>
                  <strong className="block text-slate-200 mb-1">التحميل والنقل:</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    اضغط الزر الأخضر أعلاه وحمّل الملف، ثم أرسله لهاتفك عبر واتساب أو تيليجرام أو كابل USB.
                  </p>
                </div>

                <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800">
                  <div className="w-6 h-6 rounded-full bg-teal-500 text-slate-950 font-bold flex items-center justify-center mb-2 text-xs">
                    2
                  </div>
                  <strong className="block text-slate-200 mb-1">الفتح في الهاتف:</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    اضغط على الملف داخل الهاتف واختر <strong>"فتح باستخدام Chrome"</strong> ليفتح التطبيق فوراً.
                  </p>
                </div>

                <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800">
                  <div className="w-6 h-6 rounded-full bg-teal-500 text-slate-950 font-bold flex items-center justify-center mb-2 text-xs">
                    3
                  </div>
                  <strong className="block text-slate-200 mb-1">تثبيته كأيقونة:</strong>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    من قائمة كروم (⋮) اختر <strong>"إضافة إلى الشاشة الرئيسية"</strong> وسيظهر كأيقونة تطبيق كاملة على شاشة هاتفك!
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: BUILD IN ANDROID STUDIO */}
        {activeTab === 'androidStudio' && (
          <div className="flex flex-col gap-4 mt-4 animate-fadeIn">
            <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-indigo-400 bg-indigo-950/80 border border-indigo-800/60 px-2.5 py-0.5 rounded-lg">
                  مشروع أندرويد 13 رسمي (Android Studio)
                </span>
              </div>
              <h4 className="text-base font-bold text-slate-100 mb-2">
                بناء ملف APK أصلي باستخدام برنامج Android Studio
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                إذا كنت تملك جهاز كمبيوتر وتريد ملف <strong>.apk</strong> مجمعاً وموقعاً يعمل كخدمة خلفية نظامية مع صلاحيات مسؤول الجهاز (DeviceAdminReceiver) ومكتبة Google CameraX:
              </p>

              <div className="flex flex-wrap items-center gap-2 mb-4">
                <button
                  type="button"
                  onClick={handleDownloadZip}
                  disabled={isZipping}
                  className="py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 transition-colors shadow-sm"
                >
                  <FolderArchive className="w-4 h-4" />
                  <span>{isZipping ? 'جاري التحزيم...' : 'تحميل حزمة المشروع كاملة (ZIP)'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenAndroidSource();
                  }}
                  className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <span>استعراض ملفات الكود</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Step by step guide */}
              <div className="space-y-2.5 text-xs text-slate-300 border-t border-slate-800/80 pt-4">
                <h5 className="font-bold text-slate-100">خطوات بناء الـ APK في 3 دقائق:</h5>
                <ol className="space-y-2 text-[11px] text-slate-400 list-decimal list-inside leading-relaxed">
                  <li>
                    حمّل ملف الـ ZIP أعلاه، ثم قم <strong>بفك الضغط عنه (Extract)</strong> على جهاز الكمبيوتر.
                  </li>
                  <li>
                    افتح برنامج <strong>Android Studio</strong> واضغط على خيار <strong>Open</strong>، ثم حدد مجلد <code className="text-teal-400 font-mono">LockGuard-Android13</code>.
                  </li>
                  <li>
                    انتظر ثوانٍ حتى ينتهي البرنامج من تحميل المكتبات (Gradle Sync).
                  </li>
                  <li>
                    من القائمة العلوية اضغط على:
                    <br />
                    <span className="font-mono text-teal-300 bg-slate-900 px-2 py-1 rounded inline-block mt-1">
                      Build ➔ Build Bundle(s) / APK(s) ➔ Build APK(s)
                    </span>
                  </li>
                  <li>
                    سيظهر إشعار في الزاوية السفلية باللون الأزرق: <strong>"APK(s) generated successfully"</strong> وبجانبه كلمة <strong>locate</strong>.
                  </li>
                  <li>
                    اضغط على <strong>locate</strong> وسيفتح لك المجلد وفيه ملف <strong className="text-teal-400">app-debug.apk</strong>. انقله لهاتفك وثبته فوراً!
                  </li>
                </ol>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: CLOUD GITHUB ACTIONS BUILD */}
        {activeTab === 'github' && (
          <div className="flex flex-col gap-4 mt-4 animate-fadeIn">
            <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-amber-400 bg-amber-950/80 border border-amber-800/60 px-2.5 py-0.5 rounded-lg">
                  بناء سحابي مجاني 100% بدون حاسوب قوي
                </span>
              </div>
              <h4 className="text-base font-bold text-slate-100 mb-2">
                تجميع ملف الـ APK أوتوماتيكياً عبر خوادم GitHub المجانية
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                لقد قمنا بتضمين ملف إعدادات كامل لـ <strong>GitHub Actions</strong> داخل حزمة الـ ZIP.
                هذا يعني أنه يمكنك تجميع ملف APK بنقرة واحدة سحابياً دون الحاجة لتثبيت أي برامج على حاسوبك!
              </p>

              <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 text-xs space-y-2.5 text-slate-300">
                <strong className="block text-slate-100">كيف تستخدم البناء السحابي؟</strong>
                <ol className="space-y-1.5 text-[11px] text-slate-400 list-decimal list-inside leading-relaxed">
                  <li>حمّل ملف المشروع <code className="text-teal-400">LockGuard-Android13-Complete-Project.zip</code> وفك ضغطه.</li>
                  <li>افتح موقع <strong>GitHub.com</strong> وأنشئ مستودعاً جديداً (New Repository).</li>
                  <li>ارفع ملفات المشروع إلى المستودع.</li>
                  <li>ستلاحظ أن تبويب <strong>Actions</strong> في جيت هاب بدأ تلقائياً في بناء ملف الـ APK!</li>
                  <li>خلال دقيقة واحدة، سينتهي البناء وستجد ملف الـ <strong className="text-teal-400">LockGuard-Android-APK.zip</strong> جاهزاً للتحميل المباشر وتثبيته على هاتفك!</li>
                </ol>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-4 mt-2 border-t border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-500">
            حارس قفل الشاشة · نظام أندرويد 13/14
          </span>
          <button
            type="button"
            onClick={onClose}
            className="py-2 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
}
