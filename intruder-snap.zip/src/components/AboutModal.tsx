import { X, ShieldCheck, Cpu, Smartphone, Lock, CheckCircle2 } from 'lucide-react';

interface AboutModalProps {
  appIconUrl: string;
  onClose: () => void;
}

export default function AboutModal({ appIconUrl, onClose }: AboutModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl flex flex-col max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-teal-400" />
            <span>حول حارس قفل الشاشة الذكي</span>
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Brand Showcase */}
        <div className="flex flex-col items-center text-center my-4">
          <img
            src={appIconUrl}
            alt="شعار حارس قفل الشاشة"
            className="w-16 h-16 rounded-2xl object-cover shadow-lg border border-teal-500/30 mb-3"
          />
          <h2 className="text-base font-bold text-slate-100">حارس قفل الشاشة الذكي (Lock Guard)</h2>
          <span className="text-xs text-teal-400 font-mono mt-0.5">الإصدار 1.0.0 (متوافق مع أندرويد 13 و 14)</span>
        </div>

        {/* Description & Technical explanation */}
        <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
            <h4 className="font-bold text-slate-200 mb-1 flex items-center gap-1.5">
              <Smartphone className="w-4 h-4 text-teal-400" />
              <span>فكرة عمل التطبيق:</span>
            </h4>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              يقوم التطبيق بحماية هاتفك عندما يكون مقفلاً. فور إيقاظ الشاشة وكتابة رمز القفل أو النقش بشكل خاطئ، تلتقط الكاميرا الأمامية صورة للمتطفل فوراً وتخزنها مع التاريخ والوقت دون أن يلاحظ، لتكتشف من حاول التجسس على جهازك.
            </p>
          </div>

          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
            <h4 className="font-bold text-slate-200 mb-1 flex items-center gap-1.5">
              <Cpu className="w-4 h-4 text-teal-400" />
              <span>هندسة العمل في أندرويد 13 (Background Service):</span>
            </h4>
            <ul className="text-slate-400 text-[11px] space-y-1.5 list-disc list-inside">
              <li>
                <strong className="text-slate-300">DeviceAdminReceiver:</strong> يستمع للنظام لمعرفة حدوث إدخال خاطئ للرمز عبر سياسة <code className="text-teal-400">watch-login</code>.
              </li>
              <li>
                <strong className="text-slate-300">CameraX Background Service:</strong> يفتح حساس الكاميرا الأمامية في الخلفية دون واجهة مستخدم ويلتقط إطار الصورة بأقل زمن استجابة.
              </li>
              <li>
                <strong className="text-slate-300">Unrestricted Battery:</strong> استثناء من وضع السكون التلقائي لضمان استمرار الحماية على مدار الساعة.
              </li>
            </ul>
          </div>

          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800">
            <h4 className="font-bold text-slate-200 mb-1 flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-teal-400" />
              <span>الخصوصية والأمان 100%:</span>
            </h4>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              جميع الصور والبيانات تبقى مشفرة ومحفوظة محلياً على جهازك فقط. لا يتم رفع أي صورة لأي خادم خارجي أو سحابي نهائياً.
            </p>
          </div>
        </div>

        {/* Close Button */}
        <div className="pt-4 mt-2">
          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
}
