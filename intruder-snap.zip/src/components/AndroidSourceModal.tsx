import { useState } from 'react';
import { X, Download, Copy, Check, FileCode, FolderArchive, Terminal } from 'lucide-react';
import { ANDROID_FILES, downloadAndroidProjectZip, ProjectFile } from '../services/androidProject';

interface AndroidSourceModalProps {
  onClose: () => void;
}

export default function AndroidSourceModal({ onClose }: AndroidSourceModalProps) {
  const [selectedFile, setSelectedFile] = useState<ProjectFile>(ANDROID_FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      await downloadAndroidProjectZip();
    } catch (err) {
      console.error('Failed to generate zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/80 backdrop-blur-md">
      <div className="w-full max-w-4xl h-[88vh] bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/10 text-teal-400 flex items-center justify-center shrink-0">
              <FolderArchive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-100">
                مشروع أندرويد الحقيقي كامل المصدر (Android Studio APK)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                أكواد Kotlin و XML جاهزة للتجميع على أندرويد 13 مع DeviceAdminReceiver و CameraX
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="py-2 px-3.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm"
            >
              <Download className="w-4 h-4" />
              <span>{isZipping ? 'جاري التحزيم...' : 'تحميل المشروع كاملاً (ZIP)'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Body Split */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
          {/* File sidebar selector */}
          <div className="w-full md:w-72 bg-slate-950/70 border-b md:border-b-0 md:border-l border-slate-800 p-3 overflow-y-auto flex md:flex-col gap-1.5 shrink-0">
            <div className="hidden md:block text-[11px] font-bold text-slate-500 uppercase px-2 py-1 tracking-wider">
              ملفات المشروع البرمجي
            </div>
            {ANDROID_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedFile(file)}
                  className={`text-right p-2.5 rounded-xl transition-colors flex items-center gap-2.5 text-xs whitespace-nowrap md:whitespace-normal ${
                    isSelected
                      ? 'bg-teal-500/15 text-teal-300 border border-teal-500/30'
                      : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                  }`}
                >
                  <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? 'text-teal-400' : 'text-slate-500'}`} />
                  <div className="flex flex-col min-w-0">
                    <span className="font-mono text-xs truncate">{file.filename}</span>
                    <span className="hidden md:block text-[10px] text-slate-500 line-clamp-1">
                      {file.language.toUpperCase()}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Code Viewer Panel */}
          <div className="flex-1 flex flex-col min-h-0 bg-slate-950">
            {/* File Path & Copy Action Bar */}
            <div className="p-3 bg-slate-900/60 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-2 text-slate-300 truncate">
                <Terminal className="w-4 h-4 text-teal-400 shrink-0" />
                <span className="truncate">{selectedFile.path}</span>
              </div>
              <button
                type="button"
                onClick={handleCopy}
                className="py-1 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1.5 transition-colors shrink-0"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-teal-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'تم النسخ!' : 'نسخ الكود'}</span>
              </button>
            </div>

            {/* File Purpose Description */}
            <div className="px-4 py-2 bg-slate-900/30 text-xs text-slate-400 border-b border-slate-800/60">
              💡 {selectedFile.description}
            </div>

            {/* Code Pre container */}
            <div className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-200 leading-relaxed select-text" dir="ltr">
              <pre>
                <code>{selectedFile.content}</code>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
