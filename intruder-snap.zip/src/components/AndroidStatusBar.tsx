import { useState, useEffect } from 'react';
import { Wifi, Signal, ShieldCheck, Battery } from 'lucide-react';

interface AndroidStatusBarProps {
  isGuardActive: boolean;
  lightMode?: boolean;
}

export default function AndroidStatusBar({ isGuardActive, lightMode = false }: AndroidStatusBarProps) {
  const [timeStr, setTimeStr] = useState<string>('');
  const [batteryLevel, setBatteryLevel] = useState<number>(88);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: false,
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);

    // Try battery API if available
    try {
      // @ts-expect-error BatteryManager
      if (navigator.getBattery) {
        // @ts-expect-error BatteryManager
        navigator.getBattery().then((battery) => {
          setBatteryLevel(Math.round(battery.level * 100));
          battery.addEventListener('levelchange', () => {
            setBatteryLevel(Math.round(battery.level * 100));
          });
        });
      }
    } catch {
      // Ignore
    }

    return () => clearInterval(interval);
  }, []);

  const textColor = lightMode ? 'text-slate-900' : 'text-slate-200';
  const iconColor = lightMode ? 'text-slate-800' : 'text-slate-300';

  return (
    <div
      className={`w-full px-5 py-2 flex items-center justify-between text-xs select-none tracking-tight font-medium ${textColor} transition-colors z-30`}
      dir="ltr"
    >
      {/* Left: Clock */}
      <div className="flex items-center gap-1.5 font-mono text-[13px] font-semibold tabular-nums">
        <span>{timeStr || '12:00'}</span>
        {isGuardActive && (
          <span title="حارس القفل نشط" className="inline-flex items-center text-teal-400">
            <ShieldCheck className="w-3.5 h-3.5" />
          </span>
        )}
      </div>

      {/* Center: Camera Punch hole / Notch indicator */}
      <div className="w-3.5 h-3.5 rounded-full bg-slate-950/80 border border-slate-700/50 shadow-inner flex items-center justify-center">
        <div className="w-1.5 h-1.5 rounded-full bg-slate-800"></div>
      </div>

      {/* Right: Network, Wifi, Battery */}
      <div className="flex items-center gap-2 font-mono tabular-nums">
        <Signal className={`w-3.5 h-3.5 ${iconColor}`} />
        <Wifi className={`w-3.5 h-3.5 ${iconColor}`} />
        <div className="flex items-center gap-1">
          <span className="text-[11px]">{batteryLevel}%</span>
          <div className="relative flex items-center">
            <Battery className={`w-4 h-4 ${iconColor}`} />
            <div
              className="absolute left-0.5 top-1 bottom-1 bg-teal-400 rounded-xs"
              style={{ width: `${Math.max(2, (batteryLevel / 100) * 9)}px` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
