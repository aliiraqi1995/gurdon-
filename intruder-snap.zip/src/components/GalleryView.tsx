import { useState } from 'react';
import {
  Grid,
  List,
  Trash2,
  Share2,
  Download,
  Calendar,
  Clock,
  Battery,
  Camera,
  AlertCircle,
  X,
  ZoomIn,
  Search,
} from 'lucide-react';
import { IntruderLog } from '../types';

interface GalleryViewProps {
  logs: IntruderLog[];
  viewMode: 'grid' | 'list';
  onToggleViewMode: (mode: 'grid' | 'list') => void;
  onDeleteLog: (id: string) => void;
  onClearAll: () => void;
}

export default function GalleryView({
  logs,
  viewMode,
  onToggleViewMode,
  onDeleteLog,
  onClearAll,
}: GalleryViewProps) {
  const [selectedLog, setSelectedLog] = useState<IntruderLog | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [confirmClear, setConfirmClear] = useState<boolean>(false);

  const formatDate = (timestamp: number) => {
    const d = new Date(timestamp);
    return d.toLocaleDateString('ar-EG', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatTime = (timestamp: number) => {
    const d = new Date(timestamp);
    return d.toLocaleTimeString('ar-EG', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });
  };

  const handleShare = async (log: IntruderLog) => {
    if (navigator.share) {
      try {
        // Convert data URL to blob for sharing if supported
        const res = await fetch(log.imageUrl);
        const blob = await res.blob();
        const file = new File([blob], `intruder_${log.timestamp}.jpg`, { type: 'image/jpeg' });
        await navigator.share({
          title: 'لقطة حارس قفل الشاشة',
          text: `تم رصد محاولة غير مصرح بها لفتح الهاتف في ${formatDate(log.timestamp)} الساعة ${formatTime(log.timestamp)}`,
          files: [file],
        });
      } catch {
        // Fallback to text share
        navigator.share({
          title: 'لقطة حارس قفل الشاشة',
          text: `تم رصد محاولة غير مصرح بها لفتح الهاتف برمز خاطئ [${log.attemptedCode}]`,
        });
      }
    } else {
      // Download directly
      handleDownload(log);
    }
  };

  const handleDownload = (log: IntruderLog) => {
    const a = document.createElement('a');
    a.href = log.imageUrl;
    a.download = `intruder_snapshot_${log.timestamp}.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const filteredLogs = logs.filter((log) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    const dateStr = formatDate(log.timestamp).toLowerCase();
    const timeStr = formatTime(log.timestamp).toLowerCase();
    const code = log.attemptedCode.toLowerCase();
    return dateStr.includes(q) || timeStr.includes(q) || code.includes(q);
  });

  return (
    <div className="w-full flex flex-col gap-4">
      {/* Gallery Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
        {/* Search */}
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث بالتاريخ أو الرمز الخاطئ..."
            className="w-full pl-3 pr-9 py-1.5 text-xs bg-slate-950 border border-slate-700/80 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:border-teal-500"
          />
        </div>

        {/* View Mode & Clear actions */}
        <div className="flex items-center gap-2">
          {/* Segmented Grid / List toggle */}
          <div className="flex items-center p-0.5 bg-slate-950 rounded-xl border border-slate-800">
            <button
              type="button"
              onClick={() => onToggleViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'grid'
                  ? 'bg-teal-500 text-slate-950 font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="عرض كشبكة"
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onToggleViewMode('list')}
              className={`p-1.5 rounded-lg transition-colors ${
                viewMode === 'list'
                  ? 'bg-teal-500 text-slate-950 font-medium'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
              title="عرض كقائمة"
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          {/* Clear all button */}
          {logs.length > 0 && (
            <button
              type="button"
              onClick={() => setConfirmClear(true)}
              className="px-3 py-1.5 text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 rounded-xl border border-rose-900/40 transition-colors flex items-center gap-1.5 whitespace-nowrap"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>مسح الكل</span>
            </button>
          )}
        </div>
      </div>

      {/* Confirm Clear Modal */}
      {confirmClear && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-full bg-rose-500/10 text-rose-400 mx-auto flex items-center justify-center mb-3">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-100 mb-1">تأكيد حذف جميع الصور؟</h3>
            <p className="text-xs text-slate-400 mb-5 leading-relaxed">
              سيتم حذف جميع سجلات لقطات المتطفلين بشكل دائم من ذاكرة الجهاز ولا يمكن التراجع.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="flex-1 py-2 text-xs font-medium rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearAll();
                  setConfirmClear(false);
                }}
                className="flex-1 py-2 text-xs font-semibold rounded-xl bg-rose-600 hover:bg-rose-500 text-white transition-colors"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Empty State */}
      {filteredLogs.length === 0 ? (
        <div className="w-full py-16 flex flex-col items-center justify-center text-center bg-slate-900/30 rounded-3xl border border-dashed border-slate-800 p-6">
          <div className="w-14 h-14 rounded-2xl bg-teal-500/10 text-teal-400 flex items-center justify-center mb-3">
            <Camera className="w-7 h-7" />
          </div>
          <h4 className="text-base font-semibold text-slate-200 mb-1">لا توجد محاولات تسلل مسجلة</h4>
          <p className="text-xs text-slate-400 max-w-sm leading-relaxed mb-4">
            جهازك في أمان تام! عند إدخال رمز قفل الشاشة بشكل خاطئ، سيقوم الحارس بالتقاط صورة تلقائية وحفظها هنا مع التاريخ والوقت.
          </p>
        </div>
      ) : viewMode === 'grid' ? (
        /* GRID VIEW */
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
          {filteredLogs.map((log) => (
            <div
              key={log.id}
              className="group relative bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden flex flex-col hover:border-teal-500/50 transition-all shadow-sm"
            >
              {/* Photo Area */}
              <div
                onClick={() => setSelectedLog(log)}
                className="relative aspect-3/4 w-full bg-slate-950 overflow-hidden cursor-pointer"
              >
                <img
                  src={log.imageUrl}
                  alt={`لقطة متطفل - ${formatDate(log.timestamp)}`}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />

                <div className="absolute top-2 left-2 flex items-center gap-1 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-lg text-[10px] text-slate-200">
                  <ZoomIn className="w-3 h-3 text-teal-400" />
                  <span>تكبير</span>
                </div>

                {/* Bottom Overlay Info */}
                <div className="absolute bottom-2 inset-x-2 text-right">
                  <div className="text-[11px] font-semibold text-white drop-shadow truncate">
                    {formatDate(log.timestamp)}
                  </div>
                  <div className="text-[10px] text-slate-300 font-mono flex items-center justify-between">
                    <span>{formatTime(log.timestamp)}</span>
                    <span className="text-rose-400 font-bold">خطأ [{log.attemptedCode}]</span>
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="p-2 flex items-center justify-between bg-slate-900/90 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={() => handleShare(log)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-teal-400 transition-colors"
                  title="مشاركة / حفظ"
                >
                  <Share2 className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => handleDownload(log)}
                  className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-teal-400 transition-colors"
                  title="تحميل بجودة عالية"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteLog(log.id)}
                  className="p-1.5 rounded-lg hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 transition-colors"
                  title="حذف هذه الصورة"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* LIST VIEW */
        <div className="flex flex-col gap-2">
          {filteredLogs.map((log) => (
            <div
              key={log.id}
              className="bg-slate-900 rounded-2xl border border-slate-800 p-3 flex items-center justify-between gap-3 hover:border-slate-700 transition-colors"
            >
              {/* Left thumbnail & info */}
              <div
                onClick={() => setSelectedLog(log)}
                className="flex items-center gap-3 cursor-pointer flex-1 min-w-0"
              >
                <div className="w-16 h-16 rounded-xl bg-slate-950 overflow-hidden shrink-0 border border-slate-700/60 relative">
                  <img
                    src={log.imageUrl}
                    alt="صورة المتطفل"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex flex-col min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-slate-100 truncate">
                      {formatDate(log.timestamp)}
                    </span>
                    <span className="text-xs font-mono text-rose-400 font-bold bg-rose-950/50 px-1.5 py-0.5 rounded-md border border-rose-800/40 shrink-0">
                      رمز خاطئ: {log.attemptedCode}
                    </span>
                  </div>

                  {/* Clean unboxed metadata with dot separators */}
                  <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
                    <span className="flex items-center gap-1 font-mono">
                      <Clock className="w-3 h-3 text-slate-500" />
                      {formatTime(log.timestamp)}
                    </span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span>الكاميرا الأمامية</span>
                    <span aria-hidden="true" className="text-slate-600">·</span>
                    <span className="flex items-center gap-1 font-mono">
                      <Battery className="w-3 h-3 text-slate-500" />
                      {log.deviceBatteryLevel}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => handleShare(log)}
                  className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-teal-400 transition-colors"
                  title="مشاركة الصورة"
                >
                  <Share2 className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => handleDownload(log)}
                  className="p-2 rounded-xl hover:bg-slate-800 text-slate-400 hover:text-teal-400 transition-colors"
                  title="تحميل"
                >
                  <Download className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteLog(log.id)}
                  className="p-2 rounded-xl hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 transition-colors"
                  title="حذف"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* FULL PREVIEW MODAL */}
      {selectedLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-100">تفاصيل لقطة المتطفل</h3>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                  <span>{formatDate(selectedLog.timestamp)}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono">{formatTime(selectedLog.timestamp)}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setSelectedLog(null)}
                className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Image Preview with high visibility */}
            <div className="relative flex-1 bg-black flex items-center justify-center overflow-auto p-2">
              <img
                src={selectedLog.imageUrl}
                alt="لقطة المتطفل بحجم كامل"
                className="max-h-[50vh] w-auto object-contain rounded-xl shadow-lg border border-slate-800"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Modal Metadata & Actions */}
            <div className="p-4 bg-slate-900/90 border-t border-slate-800 flex flex-col gap-3">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-400 block mb-0.5">الرمز الخاطئ المدخل:</span>
                  <span className="font-mono font-bold text-rose-400 text-sm">{selectedLog.attemptedCode}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-400 block mb-0.5">مستوى البطارية:</span>
                  <span className="font-mono font-medium text-teal-400 text-sm">{selectedLog.deviceBatteryLevel}%</span>
                </div>
              </div>

              {selectedLog.notes && (
                <div className="text-xs text-slate-400 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800/80">
                  {selectedLog.notes}
                </div>
              )}

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => handleShare(selectedLog)}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Share2 className="w-4 h-4" />
                  <span>مشاركة الصورة</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleDownload(selectedLog)}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>حفظ في الجهاز</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onDeleteLog(selectedLog.id);
                    setSelectedLog(null);
                  }}
                  className="p-2.5 rounded-xl bg-rose-950/40 border border-rose-900/40 text-rose-400 hover:bg-rose-900/50 transition-colors"
                  title="حذف"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
