import { useState, useEffect, useRef } from 'react';
import {
  X,
  Smartphone,
  Download,
  Copy,
  Check,
  QrCode,
  Share2,
  ExternalLink,
  ShieldCheck,
  FolderArchive,
  ArrowRight,
  AlertTriangle,
  FileCode,
} from 'lucide-react';
import QRCode from 'qrcode';
import { downloadAndroidProjectZip, downloadOfflineHtmlApp } from '../services/androidProject';

interface InstallModalProps {
  appIconUrl: string;
  onClose: () => void;
  onOpenAndroidSource: () => void;
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export default function InstallModal({
  appIconUrl,
  onClose,
  onOpenAndroidSource,
}: InstallModalProps) {
  const [copiedDev, setCopiedDev] = useState<boolean>(false);
  const [copiedPre, setCopiedPre] = useState<boolean>(false);
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const devUrl = 'https://ais-dev-zaub5cdx6lmvwb4sgqpbcp-618202986685.europe-west3.run.app';
  const preUrl = 'https://ais-pre-zaub5cdx6lmvwb4sgqpbcp-618202986685.europe-west3.run.app';

  useEffect(() => {
    // Check if already in standalone display mode
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    const handlePrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handlePrompt);
    return () => window.removeEventListener('beforeinstallprompt', handlePrompt);
  }, []);

  // Generate QR code on canvas using the dev URL
  useEffect(() => {
    if (canvasRef.current) {
      QRCode.toCanvas(canvasRef.current, devUrl, {
        width: 150,
        margin: 1,
        color: {
          dark: '#0f172a',
          light: '#ffffff',
        },
      }).catch((err) => console.error('QR generation failed:', err));
    }
  }, [devUrl]);

  const handleCopy = (url: string, isDev: boolean) => {
    navigator.clipboard.writeText(url);
    if (isDev) {
      setCopiedDev(true);
      setTimeout(() => setCopiedDev(false), 2500);
    } else {
      setCopiedPre(true);
      setTimeout(() => setCopiedPre(false), 2500);
    }
  };

  const handleNativeInstall = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    }
  };

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      await downloadAndroidProjectZip();
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/85 backdrop-blur-md">
      <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl flex flex-col max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <img
              src={appIconUrl}
              alt="أيقونة التطبيق"
              className="w-11 h-11 rounded-2xl object-cover border border-teal-500/30 shadow-md"
            />
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-100">
                طرق تشغيل وتثبيت التطبيق على هاتفك
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                روابط التشغيل المباشرة، النسخة الأوفلاين، وكود APK الكامل
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content body */}
        <div className="flex flex-col gap-5 mt-5">
          {/* Important Notice regarding Google Authentication */}
          <div className="bg-amber-950/40 border border-amber-600/40 rounded-2xl p-4 text-xs text-amber-200">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-amber-300 font-bold mb-1">
                  لماذا قد يظهر لك أن الرابط لا يعمل أو يطلب إذناً؟
                </strong>
                <p className="text-amber-200/90 leading-relaxed text-[11px]">
                  تطبيقات Google Cloud في بيئة المطورين تكون محمية تلقائياً بحساب المالك. لكي يفتح الرابط على هاتفك دون رسالة خطأ، يجب أن تكون مسجلاً الدخول في متصفح كروم على هاتفك بنفس حساب جوجل الخاص بك:
                  <br />
                  <strong className="font-mono text-teal-300 text-xs">alnbgyly00@gmail.com</strong>
                </p>
              </div>
            </div>
          </div>

          {/* METHOD 1: OFFLINE DIRECT FILE (ZERO AUTH / 100% WORKS ANYWHERE) */}
          <div className="bg-gradient-to-r from-teal-950/60 to-slate-950 border border-teal-500/40 rounded-3xl p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold text-teal-300 bg-teal-900/60 border border-teal-700/60 px-2.5 py-0.5 rounded-lg">
                الحل الأضمن والفوري (بدون أي حساب أو خادم)
              </span>
            </div>
            <h4 className="text-sm sm:text-base font-bold text-slate-100 mb-1">
              تحميل التطبيق كملف يعمل محلياً على هاتفك (HTML Offline App)
            </h4>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              قم بتحميل هذا الملف مباشرة الآن إلى جهازك، ثم أرسله إلى هاتفك (عبر واتساب أو تيليجرام أو كابل). عند النقر عليه واختيار فتحه عبر متصفح كروم، سيعمل التطبيق فوراً ويلتقط الصور ويحفظها محلياً في الهاتف بدون الحاجة لإنترنت أو تسجيل دخول!
            </p>

            <button
              type="button"
              onClick={downloadOfflineHtmlApp}
              className="w-full sm:w-auto py-3 px-5 rounded-2xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-teal-500/20 transition-all active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>تحميل تطبيق أوفلاين مستقل للهاتف (LockGuard-Android-App.html)</span>
            </button>
          </div>

          {/* METHOD 2: CLOUD RUN URLS */}
          <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5">
            <h4 className="text-sm font-bold text-slate-200 mb-2">
              روابط السحابة المباشرة (تتطلب تسجيل دخول بحسابك في كروم)
            </h4>
            <p className="text-xs text-slate-400 mb-3 leading-relaxed">
              إذا كنت مسجلاً في متصفح كروم بالهاتف بحسابك <span className="font-mono text-teal-400">alnbgyly00@gmail.com</span>، يمكنك استخدام أحد الرابطين التاليين:
            </p>

            {/* Link 1: Dev URL */}
            <div className="mb-3">
              <span className="text-[11px] text-slate-400 block mb-1">1. رابط التطوير المباشر (Development URL):</span>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-teal-300 truncate select-all" dir="ltr">
                  {devUrl}
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(devUrl, true)}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold shrink-0 transition-colors"
                >
                  {copiedDev ? <Check className="w-3.5 h-3.5 text-teal-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Link 2: Shared URL */}
            <div className="mb-4">
              <span className="text-[11px] text-slate-400 block mb-1">2. رابط المشاركة والمعاينة (Shared URL):</span>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-teal-300 truncate select-all" dir="ltr">
                  {preUrl}
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(preUrl, false)}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold shrink-0 transition-colors"
                >
                  {copiedPre ? <Check className="w-3.5 h-3.5 text-teal-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* QR Scan box */}
            <div className="flex items-center gap-4 bg-slate-900/60 p-3.5 rounded-2xl border border-slate-800">
              <div className="bg-white p-1.5 rounded-xl shrink-0">
                <canvas ref={canvasRef} className="block w-[110px] h-[110px]" />
              </div>
              <div className="text-xs text-slate-400 leading-relaxed">
                <strong className="text-slate-200 block mb-1">مسح الكود بكاميرا الهاتف:</strong>
                تأكد قبل فتح الرابط أن متصفح الهاتف مسجل به حسابك <span className="font-mono text-slate-300">alnbgyly00@gmail.com</span> حتى لا يرفض السيرفر الطلب.
              </div>
            </div>
          </div>

          {/* METHOD 3: NATIVE KOTLIN APK PROJECT (ANDROID STUDIO) */}
          <div className="bg-slate-950 border border-slate-800 rounded-3xl p-5">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-indigo-400 bg-indigo-950/80 border border-indigo-800/60 px-2.5 py-0.5 rounded-lg">
                الطريقة البرمجية الكاملة (تجميع ملف APK حقيقي)
              </span>
            </div>
            <h4 className="text-sm font-bold text-slate-100 mb-1">
              تحميل مشروع أندرويد 13 كامل المصدر (ZIP)
            </h4>
            <p className="text-xs text-slate-400 mb-3 leading-relaxed">
              لتثبيت التطبيق كـ APK حقيقي يعمل في الخلفية مع DeviceAdminReceiver ومكتبة CameraX، حمّل حزمة المشروع البرمجي كاملة وقم بتجميعها في Android Studio.
            </p>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button
                type="button"
                onClick={handleDownloadZip}
                disabled={isZipping}
                className="py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 transition-colors shadow-sm"
              >
                <FolderArchive className="w-4 h-4" />
                <span>{isZipping ? 'جاري التحزيم...' : 'تحميل مشروع أندرويد كاملاً (ZIP)'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAndroidSource();
                }}
                className="py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              >
                <span>معاينة الأكواد البرمجية</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Footer close */}
        <div className="pt-4 mt-2 border-t border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="py-2 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
}
