import { useState, useEffect } from 'react';
import { Lock, Delete, AlertTriangle, ShieldAlert, Sparkles, ChevronUp } from 'lucide-react';
import { AppSettings, IntruderLog } from '../types';
import {
  captureFrontCameraSnapshot,
  playKeypadClickSound,
  playWrongPinSound,
  playCameraShutterSound,
  playSecurityAlarmSound,
} from '../services/camera';
import AndroidStatusBar from './AndroidStatusBar';

interface LockScreenProps {
  settings: AppSettings;
  onUnlock: (newIntruderCaptured: boolean) => void;
  onNewIntruder: (log: IntruderLog) => void;
}

export default function LockScreen({ settings, onUnlock, onNewIntruder }: LockScreenProps) {
  const [pin, setPin] = useState<string>('');
  const [isKeypadVisible, setIsKeypadVisible] = useState<boolean>(true);
  const [failedAttempts, setFailedAttempts] = useState<number>(0);
  const [isShaking, setIsShaking] = useState<boolean>(false);
  const [isFlashActive, setIsFlashActive] = useState<boolean>(false);
  const [isCapturing, setIsCapturing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');

  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('ar-EG', {
          hour: '2-digit',
          minute: '2-digit',
          hour12: false,
        })
      );
      setCurrentDate(
        now.toLocaleDateString('ar-EG', {
          weekday: 'long',
          day: 'numeric',
          month: 'long',
        })
      );
    };

    updateDateTime();
    const interval = setInterval(updateDateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleKeyPress = (num: string) => {
    if (pin.length < 6 && !isCapturing) {
      playKeypadClickSound();
      const newPin = pin + num;
      setPin(newPin);
      setErrorMessage('');

      // Auto check if pin reaches 4 digits (standard Android PIN)
      if (newPin.length >= 4) {
        verifyPin(newPin);
      }
    }
  };

  const handleDelete = () => {
    if (pin.length > 0 && !isCapturing) {
      playKeypadClickSound();
      setPin(pin.slice(0, -1));
      setErrorMessage('');
    }
  };

  const handleClear = () => {
    setPin('');
    setErrorMessage('');
  };

  const verifyPin = async (candidatePin: string) => {
    if (candidatePin === settings.correctPin) {
      // Correct PIN - Unlock device
      setErrorMessage('');
      onUnlock(failedAttempts > 0);
    } else {
      // WRONG PIN - INTRUDER DETECTED!
      playWrongPinSound();
      setIsShaking(true);
      const newFailCount = failedAttempts + 1;
      setFailedAttempts(newFailCount);

      if (settings.playAlarmOnMaxFail) {
        playSecurityAlarmSound();
      }

      // Check if sensitivity threshold reached
      if (newFailCount >= settings.maxFailedAttempts) {
        setIsCapturing(true);
        setErrorMessage(`رمز خاطئ (${newFailCount})! جاري التقاط صورة المتطفل...`);

        // Flash screen white to illuminate face in low light if enabled
        if (settings.screenFlashlight && !settings.stealthMode) {
          setIsFlashActive(true);
          setTimeout(() => setIsFlashActive(false), 300);
        }

        if (!settings.stealthMode) {
          setTimeout(() => playCameraShutterSound(), 100);
        }

        try {
          const photoUrl = await captureFrontCameraSnapshot();
          const newLog: IntruderLog = {
            id: 'log_' + Date.now(),
            timestamp: Date.now(),
            imageUrl: photoUrl,
            attemptedCode: candidatePin,
            attemptNumber: newFailCount,
            deviceBatteryLevel: 85,
            isFrontCamera: true,
            notes: `محاولة غير مصرح بها برمز [${candidatePin}] تم توثيقها تلقائياً`,
          };
          onNewIntruder(newLog);
          setErrorMessage(`تم التقاط صورة المتطفل وتوثيقها (${newFailCount})`);
        } catch (err) {
          console.error('Camera snap failed', err);
        } finally {
          setIsCapturing(false);
        }
      } else {
        setErrorMessage(`رمز خاطئ! تبقت ${settings.maxFailedAttempts - newFailCount} محاولة قبل التقاط الصورة`);
      }

      setTimeout(() => {
        setIsShaking(false);
        setPin('');
      }, 500);
    }
  };

  return (
    <div className="relative w-full h-full min-h-[640px] flex flex-col justify-between bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 text-slate-100 select-none overflow-hidden">
      {/* Front camera screen flash overlay */}
      {isFlashActive && (
        <div className="absolute inset-0 bg-white z-50 transition-opacity duration-300 pointer-events-none" />
      )}

      {/* Top Status Bar */}
      <AndroidStatusBar isGuardActive={settings.isGuardActive} />

      {/* Main Lock Screen Header */}
      <div className="flex-1 flex flex-col items-center justify-start pt-6 px-6 z-10">
        {/* Lock Icon */}
        <div className="w-12 h-12 rounded-full bg-slate-800/80 border border-slate-700/60 flex items-center justify-center text-teal-400 mb-4 shadow-lg backdrop-blur-sm">
          <Lock className="w-5 h-5" />
        </div>

        {/* Big Android 13 Clock */}
        <div className="text-6xl font-light tracking-tight font-mono tabular-nums text-slate-50 drop-shadow-sm mb-1">
          {currentTime || '12:00'}
        </div>
        <div className="text-sm text-slate-400 font-medium mb-4">{currentDate}</div>

        {/* Guard Security Badge */}
        <div className="flex items-center gap-1.5 text-xs text-teal-400/90 bg-teal-950/40 border border-teal-800/40 px-3 py-1 rounded-full backdrop-blur-md">
          <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
          <span>حارس الكاميرا الأمامية نشط ومستعد</span>
        </div>

        {/* Interactive instructions helper */}
        <div className="mt-3 text-center">
          <p className="text-xs text-slate-400">
            أدخل أي رمز خاطئ (مثل <span className="font-mono text-amber-400">0000</span>) لاختبار التقاط الكاميرا
          </p>
          <p className="text-[11px] text-slate-500 mt-0.5">
            الرمز الصحيح لفتح الجهاز: <span className="font-mono text-teal-400 font-bold">{settings.correctPin}</span>
          </p>
        </div>
      </div>

      {/* Keypad Container */}
      <div className="w-full max-w-sm mx-auto px-6 pb-6 z-10">
        {/* PIN Dots Display */}
        <div className="flex flex-col items-center mb-6">
          <div
            className={`flex items-center justify-center gap-4 h-8 transition-transform ${
              isShaking ? 'animate-bounce text-red-400' : ''
            }`}
          >
            {[0, 1, 2, 3].map((idx) => {
              const isFilled = pin.length > idx;
              return (
                <div
                  key={idx}
                  className={`w-3.5 h-3.5 rounded-full transition-all duration-200 ${
                    isFilled
                      ? 'bg-teal-400 scale-110 shadow-sm shadow-teal-400/50'
                      : 'border-2 border-slate-600 bg-transparent'
                  }`}
                />
              );
            })}
          </div>

          {/* Feedback message */}
          {errorMessage && (
            <div className="mt-2 text-xs text-rose-400 flex items-center gap-1 text-center font-medium animate-fadeIn">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}
        </div>

        {/* Android Number Keypad */}
        <div className="grid grid-cols-3 gap-3 max-w-[280px] mx-auto" dir="ltr">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              onClick={() => handleKeyPress(digit)}
              disabled={isCapturing}
              className="w-16 h-16 rounded-full bg-slate-800/80 hover:bg-slate-700/80 active:bg-teal-600/30 border border-slate-700/60 active:scale-95 transition-all flex flex-col items-center justify-center mx-auto text-xl font-medium text-slate-100 shadow-sm backdrop-blur-sm"
            >
              <span className="font-mono">{digit}</span>
            </button>
          ))}

          {/* Clear button */}
          <button
            type="button"
            onClick={handleClear}
            disabled={isCapturing || pin.length === 0}
            className="w-16 h-16 rounded-full hover:bg-slate-800/50 active:scale-95 transition-all flex items-center justify-center mx-auto text-xs text-slate-400 hover:text-slate-200"
          >
            مسح
          </button>

          {/* Zero Digit */}
          <button
            type="button"
            onClick={() => handleKeyPress('0')}
            disabled={isCapturing}
            className="w-16 h-16 rounded-full bg-slate-800/80 hover:bg-slate-700/80 active:bg-teal-600/30 border border-slate-700/60 active:scale-95 transition-all flex flex-col items-center justify-center mx-auto text-xl font-medium text-slate-100 shadow-sm backdrop-blur-sm"
          >
            <span className="font-mono">0</span>
          </button>

          {/* Backspace / Delete button */}
          <button
            type="button"
            onClick={handleDelete}
            disabled={isCapturing || pin.length === 0}
            className="w-16 h-16 rounded-full hover:bg-slate-800/50 active:scale-95 transition-all flex items-center justify-center mx-auto text-slate-400 hover:text-slate-100"
            title="حذف رقم"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Emergency Call & Direct Unlock button for user convenience */}
        <div className="mt-5 flex items-center justify-between text-xs text-slate-400 px-3">
          <button
            type="button"
            onClick={() => onUnlock(false)}
            className="hover:text-teal-400 transition-colors flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5 text-teal-400" />
            <span>تجاوز القفل (المالك)</span>
          </button>

          <span className="text-[11px] text-slate-500 font-mono">
            {failedAttempts > 0 ? `المحاولات الفاشلة: ${failedAttempts}` : 'الجهاز مؤمن'}
          </span>
        </div>
      </div>
    </div>
  );
}
