import { useState } from 'react';
import {
  ShieldCheck,
  Camera,
  BatteryCharging,
  Bell,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { PermissionStatus } from '../types';
import { testFrontCamera } from '../services/camera';

interface PermissionsManagerProps {
  permissions: PermissionStatus;
  onUpdatePermissions: (newPerms: PermissionStatus) => void;
}

export default function PermissionsManager({
  permissions,
  onUpdatePermissions,
}: PermissionsManagerProps) {
  const [activeGuide, setActiveGuide] = useState<string | null>(null);
  const [isTestingCamera, setIsTestingCamera] = useState<boolean>(false);
  const [cameraFeedback, setCameraFeedback] = useState<string>('');

  const handleRequestCamera = async () => {
    setIsTestingCamera(true);
    setCameraFeedback('جاري طلب إذن الكاميرا الأمامية...');
    const success = await testFrontCamera();
    setIsTestingCamera(false);
    if (success) {
      setCameraFeedback('تم التحقق من إذن الكاميرا الأمامية بنجاح!');
      onUpdatePermissions({ ...permissions, camera: true });
    } else {
      setCameraFeedback('تعذر الوصول للكاميرا، يرجى السماح بالوصول في متصفحك أو هاتفك.');
    }
  };

  const handleToggleAdmin = () => {
    onUpdatePermissions({
      ...permissions,
      deviceAdmin: !permissions.deviceAdmin,
    });
  };

  const handleToggleBattery = () => {
    onUpdatePermissions({
      ...permissions,
      batteryOptimized: !permissions.batteryOptimized,
    });
  };

  const handleRequestNotifications = async () => {
    if ('Notification' in window) {
      try {
        const result = await Notification.requestPermission();
        if (result === 'granted') {
          onUpdatePermissions({ ...permissions, notifications: true });
        }
      } catch {
        onUpdatePermissions({ ...permissions, notifications: true });
      }
    } else {
      onUpdatePermissions({ ...permissions, notifications: true });
    }
  };

  return (
    <div className="w-full flex flex-col gap-4">
      {/* Intro Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-sm">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-2xl bg-teal-500/10 text-teal-400 flex items-center justify-center shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100">مركز أذونات وصلاحيات أندرويد 13</h3>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              لتشغيل الحارس في الخلفية والتقاط صورة أي متطفل فور كتابة رمز القفل خطأ، يتطلب نظام أندرويد 13 تفعيل هذه الصلاحيات الأساسية لضمان عدم إيقاف التطبيق.
            </p>
          </div>
        </div>
      </div>

      {/* Permissions Cards List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {/* 1. Camera Permission */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center">
                  <Camera className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-200">إذن الكاميرا الأمامية</h4>
                  <span className="text-[11px] text-slate-500">CAMERA & FRONT_LENS</span>
                </div>
              </div>
              {permissions.camera ? (
                <span className="flex items-center gap-1 text-[11px] text-teal-400 font-medium">
                  <CheckCircle2 className="w-4 h-4" /> مفعل
                </span>
              ) : (
                <span className="flex items-center gap-1 text-[11px] text-amber-400 font-medium">
                  <AlertCircle className="w-4 h-4" /> مطلوب
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              يسمح بالتقاط صورة صامتة عبر العدسة الأمامية لحظة رصد كتابة رمز خاطئ.
            </p>
            {cameraFeedback && (
              <p className="text-[11px] text-teal-400 mb-2 font-medium">{cameraFeedback}</p>
            )}
          </div>
          <button
            type="button"
            onClick={handleRequestCamera}
            disabled={isTestingCamera}
            className="w-full py-2 px-3 text-xs font-semibold rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 transition-colors flex items-center justify-center gap-1.5"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>{permissions.camera ? 'إعادة فحص الكاميرا الأمامية' : 'منح إذن الكاميرا الآن'}</span>
          </button>
        </div>

        {/* 2. Device Administrator */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-200">مسؤول الجهاز (Device Admin)</h4>
                  <span className="text-[11px] text-slate-500">BIND_DEVICE_ADMIN</span>
                </div>
              </div>
              {permissions.deviceAdmin ? (
                <span className="flex items-center gap-1 text-[11px] text-teal-400 font-medium">
                  <CheckCircle2 className="w-4 h-4" /> مفعل
                </span>
              ) : (
                <span className="flex items-center gap-1 text-[11px] text-rose-400 font-medium">
                  <AlertCircle className="w-4 h-4" /> متوقف
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              الصلاحية الرسمية في أندرويد للاستماع لأحداث قفل الشاشة وفشل كتابة كلمة المرور أو PIN.
            </p>
          </div>
          <button
            type="button"
            onClick={handleToggleAdmin}
            className={`w-full py-2 px-3 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5 ${
              permissions.deviceAdmin
                ? 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                : 'bg-teal-500 hover:bg-teal-400 text-slate-950'
            }`}
          >
            <span>{permissions.deviceAdmin ? 'إلغاء تفعيل مسؤول الجهاز' : 'تفعيل مسؤول الجهاز'}</span>
          </button>
        </div>

        {/* 3. Battery Optimization */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center">
                  <BatteryCharging className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-200">تجاوز توفير البطارية</h4>
                  <span className="text-[11px] text-slate-500">UNRESTRICTED BATTERY</span>
                </div>
              </div>
              {!permissions.batteryOptimized ? (
                <span className="flex items-center gap-1 text-[11px] text-teal-400 font-medium">
                  <CheckCircle2 className="w-4 h-4" /> غير مقيد
                </span>
              ) : (
                <span className="flex items-center gap-1 text-[11px] text-amber-400 font-medium">
                  <AlertCircle className="w-4 h-4" /> مقيد
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              يمنع نظام أندرويد 13 من قتل الخدمة في الخلفية عند قفل الشاشة لفترة طويلة.
            </p>
          </div>
          <button
            type="button"
            onClick={handleToggleBattery}
            className="w-full py-2 px-3 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors flex items-center justify-center gap-1.5"
          >
            <span>{!permissions.batteryOptimized ? 'البطارية مضبوطة على غير مقيد' : 'تعيين البطارية إلى غير مقيد'}</span>
          </button>
        </div>

        {/* 4. Notifications Permission */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center">
                  <Bell className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-200">صلاحية الإشعارات الفورية</h4>
                  <span className="text-[11px] text-slate-500">POST_NOTIFICATIONS</span>
                </div>
              </div>
              {permissions.notifications ? (
                <span className="flex items-center gap-1 text-[11px] text-teal-400 font-medium">
                  <CheckCircle2 className="w-4 h-4" /> مفعل
                </span>
              ) : (
                <span className="flex items-center gap-1 text-[11px] text-amber-400 font-medium">
                  <AlertCircle className="w-4 h-4" /> معطل
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              إلزامية في أندرويد 13 لإبقاء خدمة الحماية نشطة في الشريط العلوي وتنبيهك فوراً.
            </p>
          </div>
          <button
            type="button"
            onClick={handleRequestNotifications}
            className="w-full py-2 px-3 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors flex items-center justify-center gap-1.5"
          >
            <Bell className="w-3.5 h-3.5" />
            <span>{permissions.notifications ? 'الإشعارات مفعلة' : 'طلب إذن الإشعارات'}</span>
          </button>
        </div>
      </div>

      {/* OEM Battery Whitelist Guide */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-4 h-4 text-teal-400" />
            <h4 className="text-xs font-bold text-slate-200">
              دليل ضبط البطارية حسب نوع هاتفك (سامسونج، شاومي، بكسل)
            </h4>
          </div>
        </div>

        <p className="text-xs text-slate-400 mb-3 leading-relaxed">
          تقوم واجهات الهواتف الصينية وسامسونج في أندرويد 13 بإغلاق الخدمات الخلفية بعد بضع دقائق من إغلاق الشاشة لتوفير الطاقة. إليك كيفية تثبيت الحارس:
        </p>

        <div className="space-y-2">
          {[
            {
              id: 'samsung',
              title: 'سامسونج (Samsung One UI 5 / 6 - أندرويد 13)',
              steps: 'الإعدادات ➔ التطبيقات ➔ حارس القفل ➔ البطارية ➔ اختر "غير مقيد (Unrestricted)". ثم ادخل إلى العناية بالجهاز ➔ البطارية ➔ حدود استخدام الخلفية ➔ التطبيقات التي لا تدخل في وضع السكون ➔ أضف حارس القفل.',
            },
            {
              id: 'xiaomi',
              title: 'شاومي / ريدمي / بوكو (MIUI / HyperOS)',
              steps: 'الإعدادات ➔ التطبيقات ➔ إدارة التطبيقات ➔ حارس القفل ➔ فعّل خيار "التشغيل التلقائي (Autostart)" ➔ موفر البطارية ➔ اختر "لا توجد قيود (No restrictions)".',
            },
            {
              id: 'pixel',
              title: 'جوجل بكسل / أندرويد الخام (Pixel Android 13/14)',
              steps: 'الإعدادات ➔ التطبيقات ➔ حارس القفل ➔ استخدام بطارية التطبيق ➔ اختر "غير مقيدة (Unrestricted)".',
            },
          ].map((item) => (
            <div
              key={item.id}
              className="border border-slate-800/80 rounded-2xl bg-slate-950/60 overflow-hidden"
            >
              <button
                type="button"
                onClick={() => setActiveGuide(activeGuide === item.id ? null : item.id)}
                className="w-full p-3 text-right text-xs font-semibold text-slate-300 flex items-center justify-between hover:text-white"
              >
                <span>{item.title}</span>
                {activeGuide === item.id ? (
                  <ChevronUp className="w-4 h-4 text-teal-400" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-500" />
                )}
              </button>
              {activeGuide === item.id && (
                <div className="px-3 pb-3 text-xs text-slate-400 border-t border-slate-800/50 pt-2 leading-relaxed">
                  {item.steps}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
