import { useState } from 'react';
import { X, Save, KeyRound, Sliders, Volume2, Flashlight, EyeOff, Image, Download } from 'lucide-react';
import { AppSettings } from '../types';

interface SettingsModalProps {
  settings: AppSettings;
  appIconUrl: string;
  onSave: (newSettings: AppSettings) => void;
  onClose: () => void;
}

export default function SettingsModal({
  settings,
  appIconUrl,
  onSave,
  onClose,
}: SettingsModalProps) {
  const [form, setForm] = useState<AppSettings>({ ...settings });
  const [pinInput, setPinInput] = useState<string>(settings.correctPin);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = {
      ...form,
      correctPin: pinInput.trim() || '1234',
    };
    onSave(updated);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 600);
  };

  const handleDownloadIcon = () => {
    const a = document.createElement('a');
    a.href = appIconUrl;
    a.download = 'lock_guard_icon.png';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl flex flex-col max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-teal-400" />
            <span>إعدادات حارس قفل الشاشة</span>
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-4 text-xs">
          {/* PIN Setting */}
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
            <label className="flex items-center gap-2 font-semibold text-slate-200 mb-1.5">
              <KeyRound className="w-4 h-4 text-teal-400" />
              <span>رمز PIN الصحيح لفتح الجهاز</span>
            </label>
            <p className="text-[11px] text-slate-400 mb-2">
              الرمز الذي تفتحه به، وأي رقم غيره سيؤدي لالتقاط صورة فورية.
            </p>
            <input
              type="text"
              maxLength={6}
              value={pinInput}
              onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
              placeholder="1234"
              className="w-full py-2 px-3 bg-slate-900 border border-slate-700 rounded-xl text-teal-300 font-mono text-base font-bold tracking-widest text-center focus:outline-none focus:border-teal-500"
            />
          </div>

          {/* Sensitivity: Failed Attempts Threshold */}
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
            <label className="font-semibold text-slate-200 mb-1 block">
              حساسية الالتقاط (عدد المحاولات الخاطئة)
            </label>
            <p className="text-[11px] text-slate-400 mb-2.5">
              متى تلتقط الكاميرا الأمامية صورة المتطفل؟
            </p>
            <div className="grid grid-cols-3 gap-2">
              {[
                { val: 1, label: 'من المحاولة 1 (فوري)' },
                { val: 2, label: 'بعد محاولتين' },
                { val: 3, label: 'بعد 3 محاولات' },
              ].map((opt) => (
                <button
                  key={opt.val}
                  type="button"
                  onClick={() => setForm({ ...form, maxFailedAttempts: opt.val })}
                  className={`py-2 px-2 rounded-xl text-center font-medium transition-colors border ${
                    form.maxFailedAttempts === opt.val
                      ? 'bg-teal-500 text-slate-950 border-teal-400 font-bold'
                      : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Toggle Switches */}
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-3">
            {/* Screen Flashlight */}
            <label className="flex items-center justify-between cursor-pointer">
              <div className="flex items-start gap-2.5">
                <Flashlight className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-200 block">وميض الشاشة الليلي (Flash)</span>
                  <span className="text-[11px] text-slate-400">إضاءة بيضاء سريعة للشاشة لإظهار ملامح المتطفل في الظلام</span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={form.screenFlashlight}
                onChange={(e) => setForm({ ...form, screenFlashlight: e.target.checked })}
                className="w-4 h-4 accent-teal-500 rounded"
              />
            </label>

            {/* Alarm Sound */}
            <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-slate-800/60">
              <div className="flex items-start gap-2.5">
                <Volume2 className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-200 block">تشغيل صوت إنذار رادع</span>
                  <span className="text-[11px] text-slate-400">إطلاق صفارة تحذيرية لإخافة المتطفل عند إدخال الرمز خطأ</span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={form.playAlarmOnMaxFail}
                onChange={(e) => setForm({ ...form, playAlarmOnMaxFail: e.target.checked })}
                className="w-4 h-4 accent-teal-500 rounded"
              />
            </label>

            {/* Stealth Mode */}
            <label className="flex items-center justify-between cursor-pointer pt-2 border-t border-slate-800/60">
              <div className="flex items-start gap-2.5">
                <EyeOff className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-slate-200 block">وضع التخفي الكامل (Stealth)</span>
                  <span className="text-[11px] text-slate-400">التقاط صامت بالكامل دون وميض أو صوت شاتر</span>
                </div>
              </div>
              <input
                type="checkbox"
                checked={form.stealthMode}
                onChange={(e) => setForm({ ...form, stealthMode: e.target.checked })}
                className="w-4 h-4 accent-teal-500 rounded"
              />
            </label>
          </div>

          {/* App Icon Export Section */}
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src={appIconUrl}
                alt="أيقونة التطبيق"
                className="w-10 h-10 rounded-xl object-cover border border-slate-700 shadow"
              />
              <div>
                <span className="font-semibold text-slate-200 block">أيقونة التطبيق الرسمية</span>
                <span className="text-[11px] text-slate-400">صورة الأيقونة بدقة عالية (PNG / JPG)</span>
              </div>
            </div>
            <button
              type="button"
              onClick={handleDownloadIcon}
              className="py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-teal-400 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل الأيقونة</span>
            </button>
          </div>

          {/* Submit Button */}
          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 text-xs font-medium rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 text-xs font-bold rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 transition-colors flex items-center justify-center gap-1.5 shadow-md shadow-teal-500/20"
            >
              <Save className="w-4 h-4" />
              <span>{savedSuccess ? 'تم الحفظ بنجاح!' : 'حفظ الإعدادات'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
