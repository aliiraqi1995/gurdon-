/**
 * Camera and Sound Utility Service
 * Provides real front-facing camera stream capture and Web Audio sound effects
 */

let activeStream: MediaStream | null = null;
let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

/**
 * Initializes or tests front camera access
 */
export async function testFrontCamera(): Promise<boolean> {
  try {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      return false;
    }
    const stream = await navigator.mediaDevices.getUserMedia({
      video: {
        facingMode: 'user',
        width: { ideal: 720 },
        height: { ideal: 960 },
      },
      audio: false,
    });
    // Stop immediately after test
    stream.getTracks().forEach((track) => track.stop());
    return true;
  } catch (err) {
    console.warn('Front camera access test failed:', err);
    return false;
  }
}

/**
 * Captures a real photo snapshot using the device's front camera.
 * If camera permission is denied or camera unavailable, creates an illustrated fallback snapshot.
 */
export async function captureFrontCameraSnapshot(): Promise<string> {
  try {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      let stream = activeStream;
      if (!stream || !stream.active) {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: 'user',
            width: { ideal: 720 },
            height: { ideal: 960 },
          },
          audio: false,
        });
      }

      const videoTrack = stream.getVideoTracks()[0];
      if (videoTrack) {
        // Try ImageCapture API if available
        if ('ImageCapture' in window) {
          try {
            const ImageCaptureClass = (window as unknown as { ImageCapture: new (t: MediaStreamTrack) => { takePhoto: () => Promise<Blob> } }).ImageCapture;
            const imageCapture = new ImageCaptureClass(videoTrack);
            const blob = await imageCapture.takePhoto();
            return await blobToDataURL(blob);
          } catch {
            // fallback to video element canvas
          }
        }

        // Canvas video frame capture
        const video = document.createElement('video');
        video.muted = true;
        video.playsInline = true;
        video.srcObject = stream;
        await video.play();

        // Allow camera sensor auto-exposure a moment
        await new Promise((r) => setTimeout(r, 200));

        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth || 640;
        canvas.height = video.videoHeight || 480;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          // Mirror horizontally for natural selfie perspective
          ctx.translate(canvas.width, 0);
          ctx.scale(-1, 1);
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.88);
          video.pause();
          video.srcObject = null;
          // Stop stream to release camera indicator
          stream.getTracks().forEach((t) => t.stop());
          return dataUrl;
        }
      }
    }
  } catch (err) {
    console.warn('Direct camera capture failed or denied:', err);
  }

  // Fallback: Generate an authentic silhouette / mock snapshot with timestamp
  return generateSimulatedIntruderSnapshot();
}

function blobToDataURL(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

/**
 * Generates a realistic placeholder intruder selfie when webcam is unavailable or denied
 */
function generateSimulatedIntruderSnapshot(): string {
  const canvas = document.createElement('canvas');
  canvas.width = 640;
  canvas.height = 800;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Dark room gradient background
  const bgGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
  bgGrad.addColorStop(0, '#0f172a');
  bgGrad.addColorStop(0.5, '#1e293b');
  bgGrad.addColorStop(1, '#090d16');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Subtle ambient phone screen glow on face
  const glow = ctx.createRadialGradient(320, 360, 40, 320, 360, 240);
  glow.addColorStop(0, 'rgba(56, 189, 248, 0.25)');
  glow.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Intruder silhouette head & shoulders
  ctx.fillStyle = '#334155';
  ctx.beginPath();
  ctx.arc(320, 320, 110, 0, Math.PI * 2);
  ctx.fill();

  ctx.beginPath();
  ctx.ellipse(320, 620, 220, 180, 0, 0, Math.PI * 2);
  ctx.fill();

  // Screen glare reflection on face
  ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
  ctx.beginPath();
  ctx.ellipse(320, 310, 80, 80, 0, 0, Math.PI * 2);
  ctx.fill();

  // Watermark text in bottom corner
  ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
  ctx.font = 'bold 20px monospace';
  ctx.textAlign = 'right';
  const now = new Date();
  const timeStr = now.toLocaleTimeString('ar-EG', { hour12: true });
  const dateStr = now.toLocaleDateString('ar-EG');
  ctx.fillText(`CAM_FRONT · ${timeStr}`, canvas.width - 24, canvas.height - 40);
  ctx.font = '16px monospace';
  ctx.fillStyle = 'rgba(239, 68, 68, 0.9)';
  ctx.fillText(`محاولة فتح خاطئة · ${dateStr}`, canvas.width - 24, canvas.height - 18);

  return canvas.toDataURL('image/jpeg', 0.85);
}

// ================= Sound Effects (Web Audio API) =================

export function playKeypadClickSound() {
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(440, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.04);
    gain.gain.setValueAtTime(0.08, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.04);
  } catch {
    // Ignore audio restrictions
  }
}

export function playWrongPinSound() {
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, ctx.currentTime);
    osc.frequency.setValueAtTime(110, ctx.currentTime + 0.12);
    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.28);
  } catch {
    // Ignore
  }
}

export function playCameraShutterSound() {
  try {
    const ctx = getAudioContext();
    // Shutter click simulation: click + noise
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(300, ctx.currentTime + 0.05);
    gain.gain.setValueAtTime(0.25, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.05);
  } catch {
    // Ignore
  }
}

export function playSecurityAlarmSound() {
  try {
    const ctx = getAudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(950, ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(600, ctx.currentTime + 0.2);
    osc.frequency.linearRampToValueAtTime(950, ctx.currentTime + 0.4);
    osc.frequency.linearRampToValueAtTime(600, ctx.currentTime + 0.6);
    gain.gain.setValueAtTime(0.18, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.7);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.7);
  } catch {
    // Ignore
  }
}
