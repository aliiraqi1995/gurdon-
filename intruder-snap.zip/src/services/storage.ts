import { IntruderLog, AppSettings, PermissionStatus } from '../types';

const LOGS_KEY = 'lockguard_intruder_logs_v1';
const SETTINGS_KEY = 'lockguard_settings_v1';
const PERMISSIONS_KEY = 'lockguard_permissions_v1';

export const DEFAULT_SETTINGS: AppSettings = {
  correctPin: '1234',
  maxFailedAttempts: 1, // Capture immediately on first wrong PIN
  isGuardActive: true,
  stealthMode: false, // subtle indicator
  screenFlashlight: true, // Flash screen white to illuminate face in dark
  playAlarmOnMaxFail: false,
  viewMode: 'grid',
  saveToGallery: true,
};

export const DEFAULT_PERMISSIONS: PermissionStatus = {
  camera: false,
  deviceAdmin: true,
  batteryOptimized: false, // Unrestricted battery
  notifications: true,
};

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error('Failed to save settings:', e);
  }
}

export function loadPermissions(): PermissionStatus {
  try {
    const raw = localStorage.getItem(PERMISSIONS_KEY);
    if (!raw) return DEFAULT_PERMISSIONS;
    return { ...DEFAULT_PERMISSIONS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_PERMISSIONS;
  }
}

export function savePermissions(perms: PermissionStatus): void {
  try {
    localStorage.setItem(PERMISSIONS_KEY, JSON.stringify(perms));
  } catch (e) {
    console.error('Failed to save permissions:', e);
  }
}

/**
 * Creates seed demo photos so the gallery looks realistic upon first launch
 */
function createDemoLogs(): IntruderLog[] {
  const canvas = document.createElement('canvas');
  canvas.width = 480;
  canvas.height = 640;
  const ctx = canvas.getContext('2d');
  
  const generateImg = (tint: string, label: string) => {
    if (!ctx) return '';
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, 480, 640);
    // Radial light
    const rad = ctx.createRadialGradient(240, 260, 20, 240, 260, 200);
    rad.addColorStop(0, tint);
    rad.addColorStop(1, '#090d16');
    ctx.fillStyle = rad;
    ctx.fillRect(0, 0, 480, 640);

    // Silhouette
    ctx.fillStyle = '#1e293b';
    ctx.beginPath();
    ctx.arc(240, 240, 90, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(240, 480, 180, 140, 0, 0, Math.PI * 2);
    ctx.fill();

    // Eye glare
    ctx.fillStyle = 'rgba(255,255,255,0.15)';
    ctx.beginPath();
    ctx.ellipse(240, 230, 60, 60, 0, 0, Math.PI * 2);
    ctx.fill();

    // Badge
    ctx.fillStyle = '#e2e8f0';
    ctx.font = '14px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(label, 240, 600);
    return canvas.toDataURL('image/jpeg', 0.8);
  };

  const now = Date.now();
  return [
    {
      id: 'demo-1',
      timestamp: now - 1000 * 60 * 42, // 42 minutes ago
      imageUrl: generateImg('rgba(239, 68, 68, 0.3)', 'محاولة تجريبية (رمز خاطئ: 0000)'),
      attemptedCode: '0000',
      attemptNumber: 1,
      deviceBatteryLevel: 82,
      isFrontCamera: true,
      notes: 'تم التقاط الصورة عند محاولة فتح القفل الأولى أثناء وضع السكون',
    },
    {
      id: 'demo-2',
      timestamp: now - 1000 * 60 * 60 * 4, // 4 hours ago
      imageUrl: generateImg('rgba(249, 115, 22, 0.25)', 'محاولة تجريبية (رمز خاطئ: 2580)'),
      attemptedCode: '2580',
      attemptNumber: 2,
      deviceBatteryLevel: 89,
      isFrontCamera: true,
      notes: 'التقاط سري تلقائي عبر الكاميرا الأمامية بعد محاولتين غير صحيحتين',
    },
  ];
}

export function loadIntruderLogs(): IntruderLog[] {
  try {
    const raw = localStorage.getItem(LOGS_KEY);
    if (!raw) {
      const seeded = createDemoLogs();
      saveIntruderLogs(seeded);
      return seeded;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveIntruderLogs(logs: IntruderLog[]): void {
  try {
    localStorage.setItem(LOGS_KEY, JSON.stringify(logs));
  } catch (e) {
    console.error('Failed to save logs to localStorage:', e);
  }
}

export function addIntruderLog(newLog: IntruderLog): IntruderLog[] {
  const current = loadIntruderLogs();
  const updated = [newLog, ...current];
  saveIntruderLogs(updated);
  return updated;
}

export function deleteIntruderLog(id: string): IntruderLog[] {
  const current = loadIntruderLogs();
  const updated = current.filter((item) => item.id !== id);
  saveIntruderLogs(updated);
  return updated;
}

export function clearAllIntruderLogs(): void {
  localStorage.removeItem(LOGS_KEY);
}
