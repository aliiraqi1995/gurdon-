export interface IntruderLog {
  id: string;
  timestamp: number;
  imageUrl: string;
  attemptedCode: string;
  attemptNumber: number;
  deviceBatteryLevel: number;
  isFrontCamera: boolean;
  notes?: string;
}

export interface AppSettings {
  correctPin: string;
  maxFailedAttempts: number; // 1, 2, or 3
  isGuardActive: boolean;
  stealthMode: boolean; // no shutter flash
  screenFlashlight: boolean; // bright white screen flash in dark environments for camera lighting
  playAlarmOnMaxFail: boolean;
  viewMode: 'grid' | 'list';
  saveToGallery: boolean;
}

export interface PermissionStatus {
  camera: boolean;
  deviceAdmin: boolean;
  batteryOptimized: boolean; // false means ignored (unrestricted)
  notifications: boolean;
}
