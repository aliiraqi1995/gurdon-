package com.guard.lockscreen

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class IntruderPhotoItem(
    val file: File,
    val name: String,
    val formattedDate: String,
    val timestamp: Long
)

object IntruderStorage {

    private const val TAG = "IntruderStorage"

    fun getIntrudersDir(context: Context): File {
        val dir = File(context.getExternalFilesDir(null), "Intruders")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun savePhoto(context: Context, bitmap: Bitmap): File? {
        val dir = getIntrudersDir(context)
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val photoFile = File(dir, "INTRUDER_${timeStamp}.jpg")

        return try {
            FileOutputStream(photoFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
            }
            Log.d(TAG, "Intruder photo saved: ${photoFile.absolutePath}")
            photoFile
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save photo", e)
            null
        }
    }

    fun getAllPhotos(context: Context): List<IntruderPhotoItem> {
        val dir = getIntrudersDir(context)
        val files = dir.listFiles { _, name ->
            name.startsWith("INTRUDER_") && (name.endsWith(".jpg") || name.endsWith(".png"))
        } ?: arrayOf()

        val displayFormat = SimpleDateFormat("yyyy/MM/dd - hh:mm:ss a", Locale("ar"))

        return files.map { file ->
            val timestamp = file.lastModified()
            val formattedDate = displayFormat.format(Date(timestamp))
            IntruderPhotoItem(
                file = file,
                name = file.name,
                formattedDate = formattedDate,
                timestamp = timestamp
            )
        }.sortedByDescending { it.timestamp }
    }

    fun deletePhoto(photoItem: IntruderPhotoItem): Boolean {
        return try {
            photoItem.file.delete()
        } catch (e: Exception) {
            false
        }
    }

    fun deleteAllPhotos(context: Context): Boolean {
        val photos = getAllPhotos(context)
        var success = true
        for (item in photos) {
            if (!item.file.delete()) {
                success = false
            }
        }
        return success
    }

    fun getUriForPhoto(context: Context, file: File): Uri {
        val authority = "${context.packageName}.fileprovider"
        return FileProvider.getUriForFile(context, authority, file)
    }
}
