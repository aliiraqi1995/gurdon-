package com.guard.lockscreen

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.FileProvider

class MainActivity : Activity() {

    private val colorBg = 0xFF0D1117.toInt()
    private val colorSurface = 0xFF161B22.toInt()
    private val colorSurfaceAlt = 0xFF21262D.toInt()
    private val colorPrimary = 0xFF1F6FEB.toInt()
    private val colorPrimaryLight = 0xFF58A6FF.toInt()
    private val colorText = 0xFFE6EDF3.toInt()
    private val colorMuted = 0xFF8B949E.toInt()
    private val colorBorder = 0xFF30363D.toInt()
    private val colorDanger = 0xFFFF7B72.toInt()
    private val colorSuccess = 0xFF3FB950.toInt()

    private var isGridView = true
    private lateinit var photosContainer: ViewGroup
    private lateinit var statusCardText: TextView
    private lateinit var statusCardSubtext: TextView
    private lateinit var statusCardIcon: TextView
    private lateinit var btnToggleProtection: Button
    private lateinit var btnGrantPermissions: Button

    private fun dp(value: Int): Int =
        Math.round(value * resources.displayMetrics.density)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // إعداد ألوان شريط الحالة والنظام ليتناسق مع أجهزة أندرويد 13
        window.statusBarColor = colorBg
        window.navigationBarColor = colorBg

        val rootLayout = ScrollView(this).apply {
            setBackgroundColor(colorBg)
            isFillViewport = true
        }

        val mainContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        rootLayout.addView(mainContainer)

        // Top Header
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(16))
        }

        val appIconView = TextView(this).apply {
            text = "🛡️"
            textSize = 28f
        }
        headerLayout.addView(appIconView)

        val headerTextLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }

        val titleView = TextView(this).apply {
            text = "حارس القفل | LockGuard"
            setTextColor(colorText)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitleView = TextView(this).apply {
            text = "حماية إضافية والتقاط صورة المتسللين"
            setTextColor(colorMuted)
            textSize = 12f
        }
        headerTextLayout.addView(titleView)
        headerTextLayout.addView(subtitleView)

        headerLayout.addView(headerTextLayout, LinearLayout.LayoutParams(0, -2, 1f))

        // Options Menu button in header
        val btnMenu = Button(this).apply {
            text = "⋮"
            textSize = 20f
            setTextColor(colorText)
            background = GradientDrawable().apply {
                setColor(colorSurfaceAlt)
                cornerRadius = dp(8).toFloat()
            }
            setOnClickListener { view ->
                showPopupMenu(view)
            }
        }
        headerLayout.addView(btnMenu, LinearLayout.LayoutParams(dp(40), dp(40)))

        mainContainer.addView(headerLayout)

        // Protection Status Card
        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply {
                setColor(colorSurface)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), colorBorder)
            }
        }

        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        statusCardIcon = TextView(this).apply {
            text = "🔒"
            textSize = 24f
        }
        statusRow.addView(statusCardIcon)

        val statusTextLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }

        statusCardText = TextView(this).apply {
            text = "الحماية مفعلة"
            setTextColor(colorSuccess)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        }

        statusCardSubtext = TextView(this).apply {
            text = "يتم رصد محاولات فتح القفل بالرمز الخاطئ"
            setTextColor(colorMuted)
            textSize = 12f
        }

        statusTextLayout.addView(statusCardText)
        statusTextLayout.addView(statusCardSubtext)
        statusRow.addView(statusTextLayout, LinearLayout.LayoutParams(0, -2, 1f))

        statusCard.addView(statusRow)

        // Action Buttons Row inside status card
        val cardActionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(16), 0, 0)
        }

        btnToggleProtection = Button(this).apply {
            text = "تفعيل مسؤول الجهاز"
            textSize = 13f
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable().apply {
                setColor(colorPrimary)
                cornerRadius = dp(10).toFloat()
            }
            setOnClickListener {
                requestDeviceAdminPermission()
            }
        }
        cardActionRow.addView(btnToggleProtection, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            rightMargin = dp(6)
        })

        btnGrantPermissions = Button(this).apply {
            text = "الأذونات وإيقاف تقييد البطارية"
            textSize = 12f
            setTextColor(colorText)
            isAllCaps = false
            background = GradientDrawable().apply {
                setColor(colorSurfaceAlt)
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), colorBorder)
            }
            setOnClickListener {
                requestAllPermissionsAndBatteryOptimization()
            }
        }
        cardActionRow.addView(btnGrantPermissions, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            leftMargin = dp(6)
        })

        statusCard.addView(cardActionRow)
        mainContainer.addView(statusCard)

        // Section Title & Controls for Intruder Logs
        val sectionHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(24), 0, dp(12))
        }

        val sectionTitle = TextView(this).apply {
            text = "سجل صور المتسللين 📸"
            setTextColor(colorText)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        }
        sectionHeader.addView(sectionTitle, LinearLayout.LayoutParams(0, -2, 1f))

        val btnToggleView = Button(this).apply {
            text = if (isGridView) "عرض: شبكة ▦" else "عرض: قائمة ☰"
            textSize = 12f
            setTextColor(colorPrimaryLight)
            background = GradientDrawable().apply {
                setColor(colorSurface)
                cornerRadius = dp(8).toFloat()
                setStroke(dp(1), colorBorder)
            }
            setOnClickListener {
                isGridView = !isGridView
                text = if (isGridView) "عرض: شبكة ▦" else "عرض: قائمة ☰"
                refreshPhotosList()
            }
        }
        sectionHeader.addView(btnToggleView)

        mainContainer.addView(sectionHeader)

        // Container where photo items will be attached dynamically
        photosContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        mainContainer.addView(photosContainer)

        setContentView(rootLayout)

        checkPermissionsState()
        refreshPhotosList()
    }

    override fun onResume() {
        super.onResume()
        checkPermissionsState()
        refreshPhotosList()
    }

    private fun checkPermissionsState() {
        val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(this, IntruderAdminReceiver::class.java)
        val isAdminActive = dpm.isAdminActive(adminComponent)

        val cameraGranted = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val isBatteryIgnoring = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pm.isIgnoringBatteryOptimizations(packageName)
        } else {
            true
        }

        if (isAdminActive && cameraGranted) {
            statusCardIcon.text = "🛡️"
            statusCardText.text = "الحماية مفعلة وجاهزة"
            statusCardText.setTextColor(colorSuccess)
            statusCardSubtext.text = if (isBatteryIgnoring) "مسؤول الجهاز والكاميرا والبطارية مكتملة الأذونات" else "يرجى استثناء التطبيق من تحسين البطارية للعمل بدون توقف"
            btnToggleProtection.text = "مسؤول الجهاز مفعّل ✅"
        } else {
            statusCardIcon.text = "⚠️"
            statusCardText.text = "الحماية غير مكتملة"
            statusCardText.setTextColor(colorDanger)
            statusCardSubtext.text = "يتطلب تفعيل مسؤول الجهاز وإذن الكاميرا لالتقاط الصور"
            btnToggleProtection.text = "تفعيل مسؤول الجهاز"
        }
    }

    private fun requestDeviceAdminPermission() {
        val adminComponent = ComponentName(this, IntruderAdminReceiver::class.java)
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "يستخدم التطبيق مسؤول الجهاز لرصد إدخال رمز قفل الشاشة الخاطئ وتصوير المتسلل تلقائياً.")
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر فتح إعدادات مسؤول الجهاز", Toast.LENGTH_SHORT).show()
        }
    }

    private fun requestAllPermissionsAndBatteryOptimization() {
        val permissionsToRequest = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.CAMERA)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            requestPermissions(permissionsToRequest.toTypedArray(), 101)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    val batteryIntent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(batteryIntent)
                } catch (e: Exception) {
                    val genericIntent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    try { startActivity(genericIntent) } catch (_: Exception) {}
                }
            }
        }
    }

    private fun refreshPhotosList() {
        photosContainer.removeAllViews()
        val photos = IntruderStorage.getAllPhotos(this)

        if (photos.isEmpty()) {
            val emptyBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(40), dp(24), dp(40))
                background = GradientDrawable().apply {
                    setColor(colorSurface)
                    cornerRadius = dp(16).toFloat()
                    setStroke(dp(1), colorBorder)
                }
            }

            val emptyIcon = TextView(this).apply {
                text = "🖼️"
                textSize = 40f
            }
            val emptyText = TextView(this).apply {
                text = "لا توجد لقطات مصورة حالياً"
                setTextColor(colorText)
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
            }
            val emptySub = TextView(this).apply {
                text = "سيتم إدراج الصور هنا تلقائياً عند أي محاولة فتح قفل خاطئة"
                setTextColor(colorMuted)
                textSize = 12f
                gravity = Gravity.CENTER
            }

            emptyBox.addView(emptyIcon)
            emptyBox.addView(emptyText, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
            emptyBox.addView(emptySub, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) })

            photosContainer.addView(emptyBox)
            return
        }

        if (isGridView) {
            val gridContainer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
            }

            var currentRow: LinearLayout? = null
            photos.forEachIndexed { index, photoItem ->
                if (index % 2 == 0) {
                    currentRow = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        weightSum = 2f
                    }
                    gridContainer.addView(currentRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
                }

                val card = createPhotoGridCard(photoItem)
                currentRow?.addView(card, LinearLayout.LayoutParams(0, -2, 1f).apply {
                    if (index % 2 == 0) rightMargin = dp(5) else leftMargin = dp(5)
                })
            }

            // In case odd number of items, fill last slot space
            if (photos.size % 2 != 0 && currentRow != null) {
                val dummy = View(this)
                currentRow?.addView(dummy, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(5) })
            }

            photosContainer.addView(gridContainer)
        } else {
            val listContainer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
            }

            photos.forEach { photoItem ->
                val card = createPhotoListCard(photoItem)
                listContainer.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }

            photosContainer.addView(listContainer)
        }
    }

    private fun createPhotoGridCard(item: IntruderPhotoItem): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(colorSurface)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), colorBorder)
            }
            setPadding(dp(8), dp(8), dp(8), dp(8))
            isClickable = true
            setOnClickListener { showPhotoDetailsDialog(item) }
        }

        val imageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            val bmp = BitmapFactory.decodeFile(item.file.absolutePath)
            if (bmp != null) setImageBitmap(bmp) else setImageResource(android.R.drawable.ic_menu_report_image)
        }
        card.addView(imageView, LinearLayout.LayoutParams(-1, dp(120)))

        val dateText = TextView(this).apply {
            text = item.formattedDate
            setTextColor(colorText)
            textSize = 11f
            gravity = Gravity.CENTER
        }
        card.addView(dateText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        }

        val btnShare = Button(this).apply {
            text = "مشاركة 🔗"
            textSize = 10f
            setTextColor(colorPrimaryLight)
            background = null
            setOnClickListener { sharePhoto(item) }
        }

        val btnDelete = Button(this).apply {
            text = "حذف 🗑️"
            textSize = 10f
            setTextColor(colorDanger)
            background = null
            setOnClickListener { deletePhoto(item) }
        }

        btnRow.addView(btnShare)
        btnRow.addView(btnDelete)
        card.addView(btnRow)

        return card
    }

    private fun createPhotoListCard(item: IntruderPhotoItem): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(colorSurface)
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), colorBorder)
            }
            setPadding(dp(8), dp(8), dp(8), dp(8))
            isClickable = true
            setOnClickListener { showPhotoDetailsDialog(item) }
        }

        val imageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            val bmp = BitmapFactory.decodeFile(item.file.absolutePath)
            if (bmp != null) setImageBitmap(bmp) else setImageResource(android.R.drawable.ic_menu_report_image)
        }
        card.addView(imageView, LinearLayout.LayoutParams(dp(70), dp(70)))

        val textLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }

        val nameText = TextView(this).apply {
            text = "محاولة فتح غير مصرح بها"
            setTextColor(colorText)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
        }
        val dateText = TextView(this).apply {
            text = item.formattedDate
            setTextColor(colorMuted)
            textSize = 12f
        }

        textLayout.addView(nameText)
        textLayout.addView(dateText)
        card.addView(textLayout, LinearLayout.LayoutParams(0, -2, 1f))

        val btnShare = Button(this).apply {
            text = "🔗"
            textSize = 16f
            setTextColor(colorPrimaryLight)
            background = null
            setOnClickListener { sharePhoto(item) }
        }

        val btnDelete = Button(this).apply {
            text = "🗑️"
            textSize = 16f
            setTextColor(colorDanger)
            background = null
            setOnClickListener { deletePhoto(item) }
        }

        card.addView(btnShare, LinearLayout.LayoutParams(dp(40), dp(40)))
        card.addView(btnDelete, LinearLayout.LayoutParams(dp(40), dp(40)))

        return card
    }

    private fun showPhotoDetailsDialog(item: IntruderPhotoItem) {
        val builder = AlertDialog.Builder(this)
        val dialogView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(colorSurface)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }

        val imageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            val bmp = BitmapFactory.decodeFile(item.file.absolutePath)
            if (bmp != null) setImageBitmap(bmp) else setImageResource(android.R.drawable.ic_menu_report_image)
        }
        dialogView.addView(imageView, LinearLayout.LayoutParams(-1, dp(300)))

        val titleView = TextView(this).apply {
            text = "تاريخ الالتقاط: ${item.formattedDate}"
            setTextColor(colorText)
            textSize = 14f
            gravity = Gravity.CENTER
        }
        dialogView.addView(titleView, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(16), 0, 0)
        }

        val btnShare = Button(this).apply {
            text = "مشاركة"
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(colorPrimary)
                cornerRadius = dp(8).toFloat()
            }
        }

        val btnDelete = Button(this).apply {
            text = "حذف"
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(colorDanger)
                cornerRadius = dp(8).toFloat()
            }
        }

        btnRow.addView(btnShare, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(4) })
        btnRow.addView(btnDelete, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(4) })
        dialogView.addView(btnRow)

        builder.setView(dialogView)
        val dialog = builder.create()

        btnShare.setOnClickListener {
            dialog.dismiss()
            sharePhoto(item)
        }

        btnDelete.setOnClickListener {
            dialog.dismiss()
            deletePhoto(item)
        }

        dialog.show()
    }

    private fun sharePhoto(item: IntruderPhotoItem) {
        try {
            val uri = IntruderStorage.getUriForPhoto(this, item.file)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "مشاركة صورة المتسلل عبر"))
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر مشاركة الصورة", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deletePhoto(item: IntruderPhotoItem) {
        AlertDialog.Builder(this)
            .setTitle("تأكيد الحذف")
            .setMessage("هل أنت تأكد من حذف هذه اللقطة؟")
            .setPositiveButton("حذف") { _, _ ->
                if (IntruderStorage.deletePhoto(item)) {
                    Toast.makeText(this, "تم حذف اللقطة بنجاح", Toast.LENGTH_SHORT).show()
                    refreshPhotosList()
                } else {
                    Toast.makeText(this, "فشل حذف اللقطة", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun showPopupMenu(anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add(Menu.NONE, 1, Menu.NONE, "حذف جميع اللقطات 🗑️")
        popup.menu.add(Menu.NONE, 2, Menu.NONE, "طريقة العرض (شبكة / قائمة) 🔲")
        popup.menu.add(Menu.NONE, 3, Menu.NONE, "حول التطبيق ℹ️")

        popup.setOnMenuItemClickListener { menuItem ->
            when (menuItem.itemId) {
                1 -> {
                    AlertDialog.Builder(this)
                        .setTitle("مسح جميع اللقطات")
                        .setMessage("هل تريد حذف كافة صور المتسللين المحفوظة؟")
                        .setPositiveButton("مسح الكل") { _, _ ->
                            IntruderStorage.deleteAllPhotos(this)
                            refreshPhotosList()
                            Toast.makeText(this, "تم مسح جميع اللقطات", Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("إلغاء", null)
                        .show()
                    true
                }
                2 -> {
                    isGridView = !isGridView
                    refreshPhotosList()
                    true
                }
                3 -> {
                    showAboutDialog()
                    true
                }
                else -> false
            }
        }
        popup.show()
    }

    private fun showAboutDialog() {
        AlertDialog.Builder(this)
            .setTitle("حول حارس قفل الشاشة")
            .setMessage("تطبيق حماية إضافي لنظام أندرويد 13+ يقدم تجربة خفيفة وسلسة.\n\nعند كتابة رمز قفل الشاشة بشكل خاطئ، يقوم التطبيق بالتقاط صورة فورية عبر الكاميرا الأمامية مع حفظ تاريخ وساعة كل محاولة لدواعي الأمان والخصوصية.")
            .setPositiveButton("حسناً", null)
            .show()
    }
}
